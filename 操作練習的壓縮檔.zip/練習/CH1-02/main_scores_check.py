def count_records(students):
    # 請回傳學生資料總筆數
    raise NotImplementedError("請完成 count_records")


def get_average_valid_score(students):
    # 請只使用有分數的學生，回傳平均分數
    raise NotImplementedError("請完成 get_average_valid_score")


def get_need_follow_up_names(students):
    # 請回傳分數是 None 或尚未交作業的學生姓名 list
    raise NotImplementedError("請完成 get_need_follow_up_names")
