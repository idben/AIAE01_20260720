from main_scores_check import (
    count_records,
    get_average_valid_score,
    get_need_follow_up_names,
)


def build_students():
    return [
        {"姓名": "小安", "分數": 92, "已交作業": True},
        {"姓名": "小美", "分數": None, "已交作業": True},
        {"姓名": "小華", "分數": 76, "已交作業": False},
        {"姓名": "小杰", "分數": 60, "已交作業": True},
        {"姓名": "小琳", "分數": 98, "已交作業": False},
    ]


def test_count_records():
    print("---------------------------------")
    students = build_students()
    expected = 5

    try:
        actual = count_records(students)
    except NotImplementedError as error:
        print("測試：計算資料總筆數")
        print(error)
        print("失敗")
        return False

    print("測試：計算資料總筆數")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_average_valid_score():
    print("---------------------------------")
    students = build_students()
    expected = 81.5

    try:
        actual = get_average_valid_score(students)
    except NotImplementedError as error:
        print("測試：只用有分數的學生計算平均")
        print(error)
        print("失敗")
        return False

    print("測試：只用有分數的學生計算平均")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if abs(actual - expected) < 0.001:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_need_follow_up_names():
    print("---------------------------------")
    students = build_students()
    expected = ["小美", "小華", "小琳"]

    try:
        actual = get_need_follow_up_names(students)
    except NotImplementedError as error:
        print("測試：找出需要追蹤的學生")
        print(error)
        print("失敗")
        return False

    print("測試：找出需要追蹤的學生")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def main():
    results = [
        test_count_records(),
        test_get_average_valid_score(),
        test_get_need_follow_up_names(),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
