import numpy as np


def get_daily_peaks(traffic_table):
    # traffic_table 每列代表一天
    # 第 0 欄是尖峰流量，第 1 欄是離峰流量
    # 請回傳每天的尖峰流量
    raise NotImplementedError("請完成 get_daily_peaks")


def get_daily_offpeaks(traffic_table):
    # 請回傳每天的離峰流量
    raise NotImplementedError("請完成 get_daily_offpeaks")


def get_daily_gaps(traffic_table):
    # 請回傳每天「尖峰 - 離峰」的流量差
    raise NotImplementedError("請完成 get_daily_gaps")


def get_average_peak(traffic_table):
    # 請回傳尖峰流量的平均
    raise NotImplementedError("請完成 get_average_peak")


def get_busy_day_peaks(traffic_table, peak_limit):
    # 請回傳尖峰流量大於等於 peak_limit 的尖峰值陣列
    raise NotImplementedError("請完成 get_busy_day_peaks")


def count_busy_days(traffic_table, peak_limit):
    # 請回傳尖峰流量大於等於 peak_limit 的天數
    raise NotImplementedError("請完成 count_busy_days")


def get_large_gap_days(traffic_table, gap_limit):
    # 應用：請先計算每天的流量差
    # 再回傳流量差大於等於 gap_limit 的流量差陣列
    raise NotImplementedError("請完成 get_large_gap_days")


def get_traffic_summary(traffic_table):
    # 應用：請回傳一個 dict，整理三個統計值
    # {
    #     "average_peak": 尖峰流量平均,
    #     "average_offpeak": 離峰流量平均,
    #     "max_gap": 最大流量差,
    # }
    raise NotImplementedError("請完成 get_traffic_summary")
