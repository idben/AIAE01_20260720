import numpy as np

from main_numpy_traffic import (
    count_busy_days,
    get_average_peak,
    get_busy_day_peaks,
    get_daily_gaps,
    get_daily_offpeaks,
    get_daily_peaks,
    get_large_gap_days,
    get_traffic_summary,
)


def get_sample_traffic():
    return np.array([
        [1200, 400],
        [1500, 500],
        [1800, 600],
        [1100, 300],
        [2000, 700],
        [1600, 550],
        [900, 250],
    ])


def test_get_daily_peaks() -> bool:
    print("---------------------------------")
    actual = get_daily_peaks(get_sample_traffic())
    expected = np.array([1200, 1500, 1800, 1100, 2000, 1600, 900])

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期每日尖峰流量：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_daily_offpeaks() -> bool:
    print("---------------------------------")
    actual = get_daily_offpeaks(get_sample_traffic())
    expected = np.array([400, 500, 600, 300, 700, 550, 250])

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期每日離峰流量：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_daily_gaps() -> bool:
    print("---------------------------------")
    actual = get_daily_gaps(get_sample_traffic())
    expected = np.array([800, 1000, 1200, 800, 1300, 1050, 650])

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期每日流量差：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_average_peak() -> bool:
    print("---------------------------------")
    actual = get_average_peak(get_sample_traffic())
    expected = 1442.857142857143

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期尖峰流量平均：{expected}")
    print(f"實際：{actual}")

    if abs(actual - expected) < 0.001:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_busy_day_peaks() -> bool:
    print("---------------------------------")
    actual = get_busy_day_peaks(get_sample_traffic(), 1600)
    expected = np.array([1800, 2000, 1600])

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期尖峰流量大於等於 1600：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_count_busy_days() -> bool:
    print("---------------------------------")
    actual = count_busy_days(get_sample_traffic(), 1600)
    expected = 3

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期尖峰流量大於等於 1600 的天數：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_large_gap_days() -> bool:
    print("---------------------------------")
    actual = get_large_gap_days(get_sample_traffic(), 1000)
    expected = np.array([1000, 1200, 1300, 1050])

    print("輸入：一週每日尖峰與離峰流量")
    print(f"預期流量差大於等於 1000：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_traffic_summary() -> bool:
    print("---------------------------------")
    actual = get_traffic_summary(get_sample_traffic())

    print("輸入：一週每日尖峰與離峰流量")
    print("預期：average_peak 約 1442.857，average_offpeak 約 471.429，max_gap 1300")
    print(f"實際：{actual}")

    average_peak_is_correct = abs(actual.get("average_peak") - 1442.857142857143) < 0.001
    average_offpeak_is_correct = abs(actual.get("average_offpeak") - 471.42857142857144) < 0.001

    if (
        average_peak_is_correct
        and average_offpeak_is_correct
        and actual.get("max_gap") == 1300
    ):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_get_daily_peaks),
        run_test(test_get_daily_offpeaks),
        run_test(test_get_daily_gaps),
        run_test(test_get_average_peak),
        run_test(test_get_busy_day_peaks),
        run_test(test_count_busy_days),
        run_test(test_get_large_gap_days),
        run_test(test_get_traffic_summary),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
