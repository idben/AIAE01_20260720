# CH3-02 NumPy 流量練習

這個練習會讓你用 NumPy 處理一週網站每日的尖峰與離峰流量資料。

這是本章的應用練習。你不只會取出欄位，還要把切片、陣列相減、條件篩選和統計結果組合起來。

你主要修改：

```text
main_numpy_traffic.py
```

測試檔：

```text
test_numpy_traffic.py
```

完成後，在這個資料夾中執行：

```bash
python test_numpy_traffic.py
```

## 資料說明

測試檔會使用一個二維陣列：

```python
traffic_table = np.array([
    [1200, 400],
    [1500, 500],
    [1800, 600],
    [1100, 300],
    [2000, 700],
    [1600, 550],
    [900, 250],
])
```

每列代表一天：

- 第 0 欄是尖峰流量。
- 第 1 欄是離峰流量。

## 練習目標

請完成下列函式：

- `get_daily_peaks(traffic_table)`：回傳每天的尖峰流量。
- `get_daily_offpeaks(traffic_table)`：回傳每天的離峰流量。
- `get_daily_gaps(traffic_table)`：回傳每天「尖峰 - 離峰」的流量差。
- `get_average_peak(traffic_table)`：回傳尖峰流量的平均。
- `get_busy_day_peaks(traffic_table, peak_limit)`：回傳尖峰流量大於等於指定數值的尖峰值陣列。
- `count_busy_days(traffic_table, peak_limit)`：回傳尖峰流量大於等於指定數值的天數。
- `get_large_gap_days(traffic_table, gap_limit)`：回傳流量差大於等於指定數值的流量差陣列。
- `get_traffic_summary(traffic_table)`：回傳尖峰平均、離峰平均、最大流量差組成的 dict。

## 難度定位

應用：先拆出尖峰與離峰流量，再把多個計算結果組合成答案。

## 提示

取得尖峰流量：

```python
traffic_table[:, 0]
```

取得離峰流量：

```python
traffic_table[:, 1]
```

條件篩選：

```python
daily_peaks[daily_peaks >= peak_limit]
```

回傳摘要 dict：

```python
{
    "average_peak": ...,
    "average_offpeak": ...,
    "max_gap": ...,
}
```
