import pandas as pd


def create_orders_dataframe():
    # 基礎：請依照 README 的指定資料建立文具店訂單 DataFrame
    raise NotImplementedError("請完成 create_orders_dataframe")


def get_first_orders(orders_df, count):
    # 基礎：請回傳前 count 筆資料
    raise NotImplementedError("請完成 get_first_orders")


def get_last_orders(orders_df, count):
    # 基礎：請回傳最後 count 筆資料
    raise NotImplementedError("請完成 get_last_orders")


def get_order_item_by_position(orders_df, row_position):
    # 應用：請用 iloc 回傳指定列位置的品名
    raise NotImplementedError("請完成 get_order_item_by_position")


def get_order_quantity_by_id(orders_df, order_id):
    # 應用：請先把訂單編號設為索引，再用 loc 回傳指定訂單的數量
    raise NotImplementedError("請完成 get_order_quantity_by_id")


def add_subtotal_column(orders_df):
    # 應用：請回傳新增小計欄位後的 DataFrame
    # 小計 = 數量 * 單價
    # 不要改到傳入的 orders_df
    raise NotImplementedError("請完成 add_subtotal_column")


def get_order_summary(orders_df):
    # 整合：請回傳一個 dict，key 為 total_amount、highest_subtotal、average_quantity
    # total_amount 是各筆小計加總，highest_subtotal 是最高單筆小計，average_quantity 是平均數量
    raise NotImplementedError("請完成 get_order_summary")
