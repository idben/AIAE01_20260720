# CH4-03 Pandas 查資料與觀察摘要練習

這是第 4 章的第三個練習。你會處理一份文具店訂單資料，練習 `head()`、`tail()`、`loc`、`iloc`、新增小計欄位，以及整理一份簡單摘要。

你主要修改：

```text
main_pandas_stationery.py
```

測試檔：

```text
test_pandas_stationery.py
```

完成後，在這個資料夾中執行：

```bash
python test_pandas_stationery.py
```

## 難度定位

進階：同時使用 DataFrame 觀察、位置查詢、標籤查詢與欄位運算。這題比前兩題更接近一小段完整資料分析流程。

## 練習目標

請完成下列函式：

- `create_orders_dataframe()`：建立指定文具店訂單 DataFrame。
- `get_first_orders(orders_df, count)`：回傳前 `count` 筆資料。
- `get_last_orders(orders_df, count)`：回傳最後 `count` 筆資料。
- `get_order_item_by_position(orders_df, row_position)`：用 `iloc` 回傳指定位置那筆訂單的品名。
- `get_order_quantity_by_id(orders_df, order_id)`：先把 `訂單編號` 設為索引，再用 `loc` 回傳指定訂單的數量。
- `add_subtotal_column(orders_df)`：新增 `小計` 欄位，內容為 `數量 * 單價`。
- `get_order_summary(orders_df)`：回傳包含總銷售額、最高小計、平均數量、欄位名稱的 dict。

## 指定資料

| 訂單編號 | 品名 | 數量 | 單價 |
| ---: | --- | ---: | ---: |
| 101 | 筆記本 | 3 | 40 |
| 102 | 原子筆 | 5 | 12 |
| 103 | 資料夾 | 2 | 35 |
| 104 | 膠帶 | 4 | 18 |
| 105 | 便利貼 | 6 | 25 |
| 106 | 原子筆 | 2 | 12 |
| 107 | 筆記本 | 1 | 40 |
| 108 | 資料夾 | 3 | 35 |

## 摘要格式

`get_order_summary()` 請回傳：

```python
{
    "total_amount": 641,
    "highest_subtotal": 150,
    "average_quantity": 3.25,
}
```

## 提示

使用位置查詢：

```python
orders_df.iloc[row_position]["品名"]
```

使用標籤查詢：

```python
indexed_df = orders_df.set_index("訂單編號")
indexed_df.loc[order_id, "數量"]
```

新增小計欄位時，建議先複製一份 DataFrame，避免改到原本的資料。
