import pandas as pd

from main_pandas_stationery import (
    add_subtotal_column,
    create_orders_dataframe,
    get_first_orders,
    get_last_orders,
    get_order_item_by_position,
    get_order_quantity_by_id,
    get_order_summary,
)


def get_expected_orders_df():
    return pd.DataFrame({
        "訂單編號": [101, 102, 103, 104, 105, 106, 107, 108],
        "品名": ["筆記本", "原子筆", "資料夾", "膠帶", "便利貼", "原子筆", "筆記本", "資料夾"],
        "數量": [3, 5, 2, 4, 6, 2, 1, 3],
        "單價": [40, 12, 35, 18, 25, 12, 40, 35],
    })


def get_expected_orders_with_subtotal_df():
    orders_df = get_expected_orders_df()
    orders_df["小計"] = [120, 60, 70, 72, 150, 24, 40, 105]
    return orders_df


def test_create_orders_dataframe() -> bool:
    print("---------------------------------")
    actual = create_orders_dataframe()
    expected = get_expected_orders_df()

    print("預期訂單資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_first_orders() -> bool:
    print("---------------------------------")
    orders_df = get_expected_orders_df()
    actual = get_first_orders(orders_df, 3)
    expected = orders_df.head(3)

    print("預期前三筆：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_last_orders() -> bool:
    print("---------------------------------")
    orders_df = get_expected_orders_df()
    actual = get_last_orders(orders_df, 2)
    expected = orders_df.tail(2)

    print("預期最後兩筆：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_order_item_by_position() -> bool:
    print("---------------------------------")
    actual = get_order_item_by_position(get_expected_orders_df(), 5)
    expected = "原子筆"

    print("輸入：第 5 個位置")
    print(f"預期品名：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_order_quantity_by_id() -> bool:
    print("---------------------------------")
    actual = get_order_quantity_by_id(get_expected_orders_df(), 105)
    expected = 6

    print("輸入：訂單編號 105")
    print(f"預期數量：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_add_subtotal_column() -> bool:
    print("---------------------------------")
    original_df = get_expected_orders_df()
    actual = add_subtotal_column(original_df)
    expected = get_expected_orders_with_subtotal_df()

    print("預期新增小計欄：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "小計" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_order_summary() -> bool:
    print("---------------------------------")
    actual = get_order_summary(get_expected_orders_df())
    expected = {
        "total_amount": 641,
        "highest_subtotal": 150,
        "average_quantity": 3.25,
    }

    print("預期摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_orders_dataframe),
        run_test(test_get_first_orders),
        run_test(test_get_last_orders),
        run_test(test_get_order_item_by_position),
        run_test(test_get_order_quantity_by_id),
        run_test(test_add_subtotal_column),
        run_test(test_get_order_summary),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
