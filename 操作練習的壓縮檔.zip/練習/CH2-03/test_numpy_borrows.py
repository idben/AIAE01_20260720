import numpy as np

from main_numpy_borrows import (
    create_borrow_table,
    get_afternoon_minus_morning,
    get_borrow_summary,
    get_day_borrows,
    get_period_borrows,
    get_quiet_evenings,
    get_table_info,
)


def test_create_borrow_table() -> bool:
    print("---------------------------------")
    data = [
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ]
    actual = create_borrow_table(data)

    print("輸入：4 天、3 個時段的借閱數資料")
    print(f"實際型別：{type(actual)}")
    print(f"實際 shape：{actual.shape}")

    if isinstance(actual, np.ndarray) and actual.shape == (4, 3):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_table_info() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_table_info(borrow_table)

    print("輸入：4 天、3 個時段的借閱數資料")
    print("預期 shape：(4, 3)")
    print(f"實際：{actual}")

    if (
        actual.get("shape") == (4, 3)
        and actual.get("ndim") == 2
        and isinstance(actual.get("dtype"), str)
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_day_borrows() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_day_borrows(borrow_table, 2)
    expected = [22, 40, 33]

    print("輸入：4 天、3 個時段的借閱數資料")
    print(f"預期：第 3 天的借閱數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_period_borrows() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_period_borrows(borrow_table, 1)
    expected = [35, 30, 40, 26]

    print("輸入：4 天、3 個時段的借閱數資料")
    print(f"預期：所有天的第 2 個時段借閱數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_afternoon_minus_morning() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_afternoon_minus_morning(borrow_table)
    expected = [15, 12, 18, 11]

    print("輸入：4 天、3 個時段的借閱數資料")
    print(f"預期：每天下午比上午多出的借閱數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_quiet_evenings() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_quiet_evenings(borrow_table, 26)
    expected = [25, 20]

    print("輸入：4 天、3 個時段的借閱數資料")
    print(f"預期：晚上低於 26 的借閱數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_borrow_summary() -> bool:
    print("---------------------------------")
    borrow_table = np.array([
        [20, 35, 28],
        [18, 30, 25],
        [22, 40, 33],
        [15, 26, 20],
    ])
    actual = get_borrow_summary(borrow_table)

    print("輸入：4 天、3 個時段的借閱數資料")
    print("預期：平均 26.0、最高 40、最低 15、全距範圍 25")
    print(f"實際：{actual}")

    average_is_correct = abs(actual.get("average") - 26.0) < 0.001

    if (
        average_is_correct
        and actual.get("highest") == 40
        and actual.get("lowest") == 15
        and actual.get("range") == 25
    ):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_borrow_table),
        run_test(test_get_table_info),
        run_test(test_get_day_borrows),
        run_test(test_get_period_borrows),
        run_test(test_get_afternoon_minus_morning),
        run_test(test_get_quiet_evenings),
        run_test(test_get_borrow_summary),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
