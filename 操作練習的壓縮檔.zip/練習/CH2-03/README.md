# CH2-03 NumPy 借閱數表練習

這個練習會讓你用二維 NumPy 陣列處理圖書館借閱數資料。

CH2-02 已經練過兩個一維陣列的對位運算。這一題會再往前一步：你會從二維資料中取出指定列、指定欄，並用不同欄位之間的差值回答問題。

你主要修改：

```text
main_numpy_borrows.py
```

測試檔：

```text
test_numpy_borrows.py
```

完成後，在這個資料夾中執行：

```bash
python test_numpy_borrows.py
```

## 資料情境

測試檔會使用一份 4 天、3 個時段的借閱數資料：

```python
borrow_table = np.array([
    [20, 35, 28],
    [18, 30, 25],
    [22, 40, 33],
    [15, 26, 20],
])
```

你可以先把它想成：

- 每一列是一整天的借閱數。
- 每一欄是一個時段。
- 第 0 欄是上午，第 1 欄是下午，第 2 欄是晚上。

## 練習目標

請完成下列函式：

- `create_borrow_table(data)`：把 Python list 轉成 NumPy 二維陣列。
- `get_table_info(borrow_table)`：回傳 `shape`、`ndim`、`dtype`。
- `get_day_borrows(borrow_table, day_index)`：回傳指定某一天的所有借閱數。
- `get_period_borrows(borrow_table, period_index)`：回傳指定時段的所有借閱數。
- `get_afternoon_minus_morning(borrow_table)`：回傳每天「下午借閱數 - 上午借閱數」的差值。
- `get_quiet_evenings(borrow_table, borrow_limit)`：回傳晚上低於指定數量的資料。
- `get_borrow_summary(borrow_table)`：回傳平均、最高、最低、全距範圍。

## 回傳格式提醒

`get_table_info()` 請回傳 dict：

```python
{
    "shape": ...,
    "ndim": ...,
    "dtype": ...,  # 記得用 str() 把 dtype 轉成文字
}
```

`get_borrow_summary()` 請回傳 dict：

```python
{
    "average": ...,
    "highest": ...,
    "lowest": ...,
    "range": ...,
}
```

## 難度提醒

這一題會用到二維陣列的欄位切片：

```python
morning_borrows = borrow_table[:, 0]
afternoon_borrows = borrow_table[:, 1]
evening_borrows = borrow_table[:, 2]
```

你可以先把每一欄取出來，放進清楚的變數，再做相減或篩選。不要急著把所有程式擠在同一行。
