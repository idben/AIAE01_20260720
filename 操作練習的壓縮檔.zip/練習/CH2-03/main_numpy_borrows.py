import numpy as np


def create_borrow_table(data):
    # 請把 Python list 轉成 NumPy 二維陣列後回傳
    raise NotImplementedError("請完成 create_borrow_table")


def get_table_info(borrow_table):
    # 請回傳一個 dict，key 為 shape、ndim、dtype
    # shape 是 tuple，ndim 是整數，dtype 請轉成文字
    raise NotImplementedError("請完成 get_table_info")


def get_day_borrows(borrow_table, day_index):
    # 請回傳指定某一天的所有借閱數
    raise NotImplementedError("請完成 get_day_borrows")


def get_period_borrows(borrow_table, period_index):
    # 請回傳指定時段的所有借閱數
    raise NotImplementedError("請完成 get_period_borrows")


def get_afternoon_minus_morning(borrow_table):
    # 請回傳每天「下午借閱數 - 上午借閱數」的差值
    raise NotImplementedError("請完成 get_afternoon_minus_morning")


def get_quiet_evenings(borrow_table, borrow_limit):
    # 請回傳晚上低於 borrow_limit 的借閱數
    raise NotImplementedError("請完成 get_quiet_evenings")


def get_borrow_summary(borrow_table):
    # 請回傳一個 dict，key 為 average、highest、lowest、range
    # 分別是平均、最高、最低、全距（最高減最低）
    # 統計對象是整張表的所有數值
    raise NotImplementedError("請完成 get_borrow_summary")
