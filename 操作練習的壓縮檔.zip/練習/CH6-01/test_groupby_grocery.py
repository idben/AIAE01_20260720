from pathlib import Path

import pandas as pd

from main_groupby_grocery import (
    add_subtotal_column,
    get_quantity_by_item,
    get_sales_by_item,
    get_top_item_by_sales,
    load_orders_csv,
)


DATA_PATH = Path(__file__).parent / "data" / "groceries.csv"


def get_orders_df():
    return pd.DataFrame({
        "訂單編號": [101, 102, 103, 104, 105, 106, 107],
        "品項": ["蘋果", "雞蛋", "蘋果", "牛奶", "雞蛋", "蘋果", "香蕉"],
        "數量": [3, 2, 1, 2, 4, 2, 5],
        "單價": [25, 60, 25, 45, 60, 25, 15],
    })


def get_orders_with_subtotal_df():
    orders_df = get_orders_df()
    orders_df["小計"] = [75, 120, 25, 90, 240, 50, 75]
    return orders_df


def test_load_orders_csv() -> bool:
    print("---------------------------------")
    actual = load_orders_csv(DATA_PATH)
    expected = get_orders_df()

    print("預期讀取 CSV 後的資料：")
    print(expected)
    print("實際：")
    print(actual)

    is_dataframe = isinstance(actual, pd.DataFrame)
    row_count_ok = is_dataframe and len(actual) == 7
    columns_ok = is_dataframe and list(actual.columns) == ["訂單編號", "品項", "數量", "單價"]
    first_row_ok = (
        row_count_ok
        and actual.iloc[0]["品項"] == "蘋果"
        and actual.iloc[0]["數量"] == 3
        and actual.iloc[0]["單價"] == 25
    )

    if row_count_ok and columns_ok and first_row_ok and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_subtotal_column() -> bool:
    print("---------------------------------")
    original_df = load_orders_csv(DATA_PATH)
    actual = add_subtotal_column(original_df)
    expected = get_orders_with_subtotal_df()

    print("預期新增小計後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "小計" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_quantity_by_item() -> bool:
    print("---------------------------------")
    actual = get_quantity_by_item(load_orders_csv(DATA_PATH))
    expected = pd.DataFrame({
        "品項": ["牛奶", "蘋果", "雞蛋", "香蕉"],
        "總數量": [2, 6, 6, 5],
    })

    print("預期每種品項總數量：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_sales_by_item() -> bool:
    print("---------------------------------")
    actual = get_sales_by_item(load_orders_csv(DATA_PATH))
    expected = pd.DataFrame({
        "品項": ["雞蛋", "蘋果", "牛奶", "香蕉"],
        "總銷售額": [360, 150, 90, 75],
    }, index=[2, 1, 0, 3])

    print("預期每種品項總銷售額：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_top_item_by_sales() -> bool:
    print("---------------------------------")
    actual = get_top_item_by_sales(load_orders_csv(DATA_PATH))
    expected = "雞蛋"

    print(f"預期總銷售額最高品項：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_orders_csv),
        run_test(test_add_subtotal_column),
        run_test(test_get_quantity_by_item),
        run_test(test_get_sales_by_item),
        run_test(test_get_top_item_by_sales),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
