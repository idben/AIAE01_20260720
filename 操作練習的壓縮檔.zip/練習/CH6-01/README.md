# CH6-01 Pandas 分組加總練習

這是第 6 章的第一個練習。你會從一份超市生鮮銷售訂單資料開始，練習新增 `小計` 欄位，並使用 `groupby()` 計算每種品項的總數量與總銷售額。

你主要修改：

```text
main_groupby_grocery.py
```

測試檔：

```text
test_groupby_grocery.py
```

資料檔：

```text
data/groceries.csv
```

完成後，在這個資料夾中執行：

```bash
python test_groupby_grocery.py
```

## 難度定位

基礎：先專心練習單一表格的分組加總，熟悉 `groupby()`、`sum()`、`reset_index()` 和排序。

## 練習目標

請完成下列函式：

- `load_orders_csv(csv_path)`：讀取 `csv_path` 指定的 CSV 檔案，回傳 DataFrame。
- `add_subtotal_column(orders_df)`：新增 `小計` 欄位，內容為 `數量 * 單價`。
- `get_quantity_by_item(orders_df)`：依照 `品項` 分組，回傳每種品項的總數量 DataFrame。
- `get_sales_by_item(orders_df)`：依照 `品項` 分組，回傳每種品項的總銷售額 DataFrame。
- `get_top_item_by_sales(orders_df)`：回傳總銷售額最高的品項名稱。

## 資料欄位

`data/groceries.csv` 有下列欄位：

- `訂單編號`
- `品項`
- `數量`
- `單價`

## 輸出欄位

`get_quantity_by_item()` 請回傳欄位：

```text
品項, 總數量
```

`get_sales_by_item()` 請回傳欄位：

```text
品項, 總銷售額
```

`get_sales_by_item()` 的結果請依照 `總銷售額` 從高到低排序。

## 提示

分組加總後，可以用 `reset_index()` 變回 DataFrame：

```python
summary_df = orders_df.groupby("品項")["數量"].sum().reset_index()
```

重新命名欄位：

```python
summary_df = summary_df.rename(columns={"數量": "總數量"})
```

## 常見錯誤

這題的測試會檢查原本傳入的 DataFrame 是否被改到。新增欄位時，建議先用 `copy()` 複製一份新資料。

如果看到 `FileNotFoundError`，請確認你是在 `CH6-01` 資料夾中執行測試檔，或確認 `data/groceries.csv` 是否存在。
