import pandas as pd


def load_orders_csv(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV 檔案，內容照實回傳為 DataFrame
    raise NotImplementedError("請完成 load_orders_csv")


def add_subtotal_column(orders_df):
    # 基礎：請回傳新增小計欄位後的 DataFrame
    # 小計 = 數量 * 單價
    # 不要改到傳入的 orders_df
    raise NotImplementedError("請完成 add_subtotal_column")


def get_quantity_by_item(orders_df):
    # 基礎：請依照品項分組，計算每種品項的總數量
    # 回傳 DataFrame，欄位為 品項、總數量
    raise NotImplementedError("請完成 get_quantity_by_item")


def get_sales_by_item(orders_df):
    # 應用：請依照品項分組，計算每種品項的總銷售額
    # 回傳 DataFrame，欄位為 品項、總銷售額，依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_sales_by_item")


def get_top_item_by_sales(orders_df):
    # 整合：請回傳總銷售額最高的品項名稱（字串）
    raise NotImplementedError("請完成 get_top_item_by_sales")
