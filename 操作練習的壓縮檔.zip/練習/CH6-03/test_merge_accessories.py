from pathlib import Path

import pandas as pd

from main_merge_accessories import (
    add_sales_amount,
    build_complete_report,
    get_category_report,
    get_product_report,
    load_csv_files,
    merge_orders_with_products,
)


DATA_DIR = Path(__file__).parent / "data"
ORDERS_PATH = DATA_DIR / "orders.csv"
PRODUCTS_PATH = DATA_DIR / "products.csv"


def get_expected_orders_df():
    return pd.DataFrame({
        "訂單編號": [501, 502, 503, 504, 505, 506, 507, 508],
        "商品編號": ["P01", "P03", "P04", "P05", "P02", "P04", "P03", "P01"],
        "數量": [2, 1, 2, 1, 3, 1, 2, 2],
    })


def get_expected_products_df():
    return pd.DataFrame({
        "商品編號": ["P01", "P02", "P03", "P04", "P05"],
        "商品名稱": ["保護殼", "鋼化膜", "充電線", "行動電源", "藍牙耳機"],
        "分類": ["保護類", "保護類", "充電類", "充電類", "音訊類"],
        "單價": [199, 149, 249, 590, 890],
    })


def get_expected_merged_df():
    return pd.DataFrame({
        "訂單編號": [501, 502, 503, 504, 505, 506, 507, 508],
        "商品編號": ["P01", "P03", "P04", "P05", "P02", "P04", "P03", "P01"],
        "數量": [2, 1, 2, 1, 3, 1, 2, 2],
        "商品名稱": ["保護殼", "充電線", "行動電源", "藍牙耳機", "鋼化膜", "行動電源", "充電線", "保護殼"],
        "分類": ["保護類", "充電類", "充電類", "音訊類", "保護類", "充電類", "充電類", "保護類"],
        "單價": [199, 249, 590, 890, 149, 590, 249, 199],
    })


def get_expected_with_sales_df():
    merged_df = get_expected_merged_df()
    merged_df["銷售額"] = [398, 249, 1180, 890, 447, 590, 498, 398]
    return merged_df


def get_expected_product_report_df():
    return pd.DataFrame({
        "商品編號": ["P04", "P05", "P01", "P03", "P02"],
        "商品名稱": ["行動電源", "藍牙耳機", "保護殼", "充電線", "鋼化膜"],
        "分類": ["充電類", "音訊類", "保護類", "充電類", "保護類"],
        "總數量": [3, 1, 4, 3, 3],
        "訂單筆數": [2, 1, 2, 2, 1],
        "總銷售額": [1770, 890, 796, 747, 447],
    }, index=[3, 4, 0, 2, 1])


def get_expected_category_report_df():
    return pd.DataFrame({
        "分類": ["充電類", "保護類", "音訊類"],
        "總數量": [6, 7, 1],
        "訂單筆數": [4, 3, 1],
        "總銷售額": [2517, 1243, 890],
    }, index=[1, 0, 2])


def test_load_csv_files() -> bool:
    print("---------------------------------")
    actual_orders, actual_products = load_csv_files(ORDERS_PATH, PRODUCTS_PATH)
    expected_orders = get_expected_orders_df()
    expected_products = get_expected_products_df()

    print("預期訂單資料：")
    print(expected_orders)
    print("實際訂單資料：")
    print(actual_orders)
    print("預期商品資料：")
    print(expected_products)
    print("實際商品資料：")
    print(actual_products)

    if (
        isinstance(actual_orders, pd.DataFrame)
        and isinstance(actual_products, pd.DataFrame)
        and actual_orders.equals(expected_orders)
        and actual_products.equals(expected_products)
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_merge_orders_with_products() -> bool:
    print("---------------------------------")
    original_orders = get_expected_orders_df()
    original_products = get_expected_products_df()
    actual = merge_orders_with_products(original_orders, original_products)
    expected = get_expected_merged_df()

    print("預期合併後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "商品名稱" not in original_orders.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_sales_amount() -> bool:
    print("---------------------------------")
    original_df = get_expected_merged_df()
    actual = add_sales_amount(original_df)
    expected = get_expected_with_sales_df()

    print("預期新增銷售額後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "銷售額" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_product_report() -> bool:
    print("---------------------------------")
    actual = get_product_report(get_expected_with_sales_df())
    expected = get_expected_product_report_df()

    print("預期商品銷售報表：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_category_report() -> bool:
    print("---------------------------------")
    actual = get_category_report(get_expected_with_sales_df())
    expected = get_expected_category_report_df()

    print("預期分類銷售報表：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_build_complete_report() -> bool:
    print("---------------------------------")
    actual = build_complete_report(ORDERS_PATH, PRODUCTS_PATH)

    print("預期完整報表包含 product_report、category_report、total_sales")
    print("實際：")
    print(actual)

    required_keys = {"product_report", "category_report", "total_sales"}
    has_required_keys = isinstance(actual, dict) and set(actual.keys()) == required_keys

    if not has_required_keys:
        print("失敗")
        return False

    product_ok = actual["product_report"].equals(get_expected_product_report_df())
    category_ok = actual["category_report"].equals(get_expected_category_report_df())
    total_ok = actual["total_sales"] == 4650

    if product_ok and category_ok and total_ok:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_csv_files),
        run_test(test_merge_orders_with_products),
        run_test(test_add_sales_amount),
        run_test(test_get_product_report),
        run_test(test_get_category_report),
        run_test(test_build_complete_report),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
