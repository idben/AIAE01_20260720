# CH6-03 Pandas merge 銷售報表練習

這是第 6 章的第三個練習。你會讀取兩份 CSV：手機配件賣場的訂單明細與商品資料，使用 `merge()` 依照 `商品編號` 合併，最後完成商品與分類銷售報表。

你主要修改：

```text
main_merge_accessories.py
```

測試檔：

```text
test_merge_accessories.py
```

資料檔：

```text
data/orders.csv
data/products.csv
```

完成後，在這個資料夾中執行：

```bash
python test_merge_accessories.py
```

## 難度定位

挑戰：這題會把第 5 章的 CSV 讀取、第 6 章的 `merge()`、新增欄位、`groupby()`、`agg()` 和排序串在一起。

## 練習目標

請完成下列函式：

- `load_csv_files(orders_path, products_path)`：讀取兩份 CSV，回傳 `(orders_df, products_df)`。
- `merge_orders_with_products(orders_df, products_df)`：依照 `商品編號` 合併兩份資料。
- `add_sales_amount(merged_df)`：新增 `銷售額` 欄位，內容為 `數量 * 單價`。
- `get_product_report(merged_df)`：依照 `商品編號`、`商品名稱`、`分類` 分組，產生商品銷售報表。
- `get_category_report(merged_df)`：依照 `分類` 分組，產生分類銷售報表。
- `build_complete_report(orders_path, products_path)`：讀取 CSV、合併、新增銷售額，最後回傳報表 dict。

## 報表格式

`build_complete_report()` 請回傳：

```python
{
    "product_report": product_report_df,
    "category_report": category_report_df,
    "total_sales": ...,
}
```

## 商品報表欄位

```text
商品編號, 商品名稱, 分類, 總數量, 訂單筆數, 總銷售額
```

結果請依照 `總銷售額` 從高到低排序。

## 分類報表欄位

```text
分類, 總數量, 訂單筆數, 總銷售額
```

結果請依照 `總銷售額` 從高到低排序。

## 提示

合併兩份資料：

```python
merged_df = orders_df.merge(products_df, on="商品編號")
```

依照多個欄位分組：

```python
merged_df.groupby(["商品編號", "商品名稱", "分類"])
```

## 常見錯誤

`merge()` 前請先確認兩份資料都有 `商品編號` 欄位。如果看到 `KeyError`，先印出：

```python
print(orders_df.columns.tolist())
print(products_df.columns.tolist())
```
