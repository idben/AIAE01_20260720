import pandas as pd


def load_csv_files(orders_path, products_path):
    # 基礎：請讀取兩份 CSV，內容照實回傳為 (orders_df, products_df)
    raise NotImplementedError("請完成 load_csv_files")


def merge_orders_with_products(orders_df, products_df):
    # 基礎：請依照商品編號合併訂單資料與商品資料，不要改到傳入資料
    # 合併後欄位為 訂單編號、商品編號、數量、商品名稱、分類、單價
    raise NotImplementedError("請完成 merge_orders_with_products")


def add_sales_amount(merged_df):
    # 基礎：請新增銷售額欄位，內容為 數量 * 單價
    # 不要改到傳入的 merged_df
    raise NotImplementedError("請完成 add_sales_amount")


def get_product_report(merged_df):
    # 應用：請依照商品編號、商品名稱、分類分組，產生商品銷售報表
    # 回傳欄位為 商品編號、商品名稱、分類、總數量、訂單筆數、總銷售額
    # 依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_product_report")


def get_category_report(merged_df):
    # 應用：請依照分類分組，產生分類銷售報表
    # 回傳欄位為 分類、總數量、訂單筆數、總銷售額，依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_category_report")


def build_complete_report(orders_path, products_path):
    # 整合：請讀取、合併、新增銷售額，並回傳完整報表 dict
    # 回傳 dict，含三個 key：
    #   product_report：商品銷售報表 DataFrame
    #   category_report：分類銷售報表 DataFrame
    #   total_sales：所有訂單的總銷售額
    raise NotImplementedError("請完成 build_complete_report")
