# CH2-01 NumPy 成績練習

這個練習會讓你用 NumPy 處理一批成績資料。

你主要修改：

```text
main_numpy_scores.py
```

測試檔：

```text
test_numpy_scores.py
```

原則上不需要修改測試檔。你完成 `main_numpy_scores.py` 後，在這個資料夾中執行：

```bash
python test_numpy_scores.py
```

## 練習目標

請完成下列函式：

- `create_score_array(scores)`：把 Python list 轉成 NumPy 陣列。
- `get_array_info(score_array)`：回傳陣列的 `shape`、`ndim`、`dtype`。
- `add_bonus(score_array, bonus)`：把陣列中的每個分數都加上 bonus。
- `get_scores_at_least(score_array, score_limit)`：回傳大於等於指定分數的成績。
- `get_score_summary(score_array)`：回傳平均、最高、最低、總和。
- `get_student_scores(score_table, student_index)`：回傳指定學生的所有成績。
- `get_subject_scores(score_table, subject_index)`：回傳所有學生在指定科目的成績。
- `get_score_slice(score_array, start, end)`：用範圍切片回傳從索引 start 到 end 前一個位置的分數。
- `get_last_score(score_array)`：用負索引回傳最後一個分數。

## 回傳格式提醒

`get_array_info()` 請回傳 dict：

```python
{
    "shape": ...,
    "ndim": ...,
    "dtype": ...,  # 記得用 str() 把 dtype 轉成文字
}
```

`get_score_summary()` 請回傳 dict：

```python
{
    "average": ...,
    "highest": ...,
    "lowest": ...,
    "total": ...,
}
```

## 常見錯誤

如果你看到：

```text
ModuleNotFoundError: No module named 'numpy'
```

通常代表目前 Python 環境找不到 NumPy。請確認你已經切換到課程指定的 Conda 環境。

如果你看到：

```text
NotImplementedError
```

代表該函式還沒有完成。請回到 `main_numpy_scores.py`，把 `raise NotImplementedError(...)` 改成你的程式。
