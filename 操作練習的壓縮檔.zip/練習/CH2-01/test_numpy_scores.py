import numpy as np

from main_numpy_scores import (
    add_bonus,
    create_score_array,
    get_array_info,
    get_last_score,
    get_score_slice,
    get_score_summary,
    get_scores_at_least,
    get_student_scores,
    get_subject_scores,
)


def test_create_score_array() -> bool:
    print("---------------------------------")
    actual = create_score_array([80, 90, 75, 60, 95])

    print("輸入：[80, 90, 75, 60, 95]")
    print(f"實際型別：{type(actual)}")
    print(f"實際內容：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == [80, 90, 75, 60, 95]:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_array_info() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = get_array_info(score_array)

    expected_shape = (5,)
    expected_ndim = 1

    print("輸入：一維成績陣列")
    print(f"預期 shape：{expected_shape}")
    print(f"實際 shape：{actual.get('shape')}")
    print(f"預期 ndim：{expected_ndim}")
    print(f"實際 ndim：{actual.get('ndim')}")
    print(f"實際 dtype：{actual.get('dtype')}")

    if (
        actual.get("shape") == expected_shape
        and actual.get("ndim") == expected_ndim
        and isinstance(actual.get("dtype"), str)
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_bonus() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = add_bonus(score_array, 5)
    expected = [85, 95, 80, 65, 100]

    print("輸入：[80, 90, 75, 60, 95]，每個分數加 5")
    print(f"預期：{expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_scores_at_least() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = get_scores_at_least(score_array, 80)
    expected = [80, 90, 95]

    print("輸入：[80, 90, 75, 60, 95]")
    print(f"預期：大於等於 80 的分數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_score_summary() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = get_score_summary(score_array)

    print("輸入：[80, 90, 75, 60, 95]")
    print("預期：平均 80.0、最高 95、最低 60、總和 400")
    print(f"實際：{actual}")

    average_is_correct = abs(actual.get("average") - 80.0) < 0.001

    if (
        average_is_correct
        and actual.get("highest") == 95
        and actual.get("lowest") == 60
        and actual.get("total") == 400
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_student_scores() -> bool:
    print("---------------------------------")
    score_table = np.array([
        [80, 90, 75],
        [88, 76, 92],
        [60, 85, 70],
        [95, 91, 89],
    ])

    actual = get_student_scores(score_table, 1)
    expected = [88, 76, 92]

    print("輸入：4 位學生、3 科成績")
    print(f"預期：第 2 位學生的成績是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_subject_scores() -> bool:
    print("---------------------------------")
    score_table = np.array([
        [80, 90, 75],
        [88, 76, 92],
        [60, 85, 70],
        [95, 91, 89],
    ])

    actual = get_subject_scores(score_table, 0)
    expected = [80, 88, 60, 95]

    print("輸入：4 位學生、3 科成績")
    print(f"預期：所有學生第 1 科成績是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_score_slice() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = get_score_slice(score_array, 1, 4)
    expected = [90, 75, 60]

    print("輸入：[80, 90, 75, 60, 95]")
    print(f"預期：索引 1 到 4 前一個位置的分數是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_last_score() -> bool:
    print("---------------------------------")
    score_array = np.array([80, 90, 75, 60, 95])
    actual = get_last_score(score_array)
    expected = 95

    print("輸入：[80, 90, 75, 60, 95]")
    print(f"預期：最後一個分數是 {expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_score_array),
        run_test(test_get_array_info),
        run_test(test_add_bonus),
        run_test(test_get_scores_at_least),
        run_test(test_get_score_summary),
        run_test(test_get_student_scores),
        run_test(test_get_subject_scores),
        run_test(test_get_score_slice),
        run_test(test_get_last_score),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
