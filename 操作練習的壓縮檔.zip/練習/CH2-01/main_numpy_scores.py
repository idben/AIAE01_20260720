import numpy as np


def create_score_array(scores):
    # 請把 Python list 轉成 NumPy 陣列後回傳
    raise NotImplementedError("請完成 create_score_array")


def get_array_info(score_array):
    # 請回傳一個 dict，key 為 shape、ndim、dtype
    # shape 是 tuple，ndim 是整數，dtype 請轉成文字
    raise NotImplementedError("請完成 get_array_info")


def add_bonus(score_array, bonus):
    # 請把陣列中的每個分數都加上 bonus 後回傳
    raise NotImplementedError("請完成 add_bonus")


def get_scores_at_least(score_array, score_limit):
    # 請回傳大於等於 score_limit 的分數
    raise NotImplementedError("請完成 get_scores_at_least")


def get_score_summary(score_array):
    # 請回傳一個 dict，key 為 average、highest、lowest、total
    # 分別是平均、最高、最低、總和
    raise NotImplementedError("請完成 get_score_summary")


def get_student_scores(score_table, student_index):
    # score_table 是二維陣列，請回傳指定學生的所有成績
    raise NotImplementedError("請完成 get_student_scores")


def get_subject_scores(score_table, subject_index):
    # score_table 是二維陣列，請回傳所有學生在指定科目的成績
    raise NotImplementedError("請完成 get_subject_scores")


def get_score_slice(score_array, start, end):
    # 請用範圍切片回傳從索引 start 到 end 前一個位置的分數
    raise NotImplementedError("請完成 get_score_slice")


def get_last_score(score_array):
    # 請用負索引回傳最後一個分數
    raise NotImplementedError("請完成 get_last_score")
