# CH4-01 Pandas Series 基礎練習

這是第 4 章的第一個練習。你會先只處理一欄資料，練習建立 `Series`、用索引取值、做基本統計和條件篩選。

情境：以影片名為索引、觀看次數為資料的 `Series`。

你主要修改：

```text
main_pandas_series.py
```

測試檔：

```text
test_pandas_series.py
```

完成後，在這個資料夾中執行：

```bash
python test_pandas_series.py
```

## 難度定位

基礎：只處理一欄觀看次數資料，目標是看懂 `Series` 的索引與數值。

## 練習目標

請完成下列函式：

- `create_view_series(video_names, views)`：建立以影片名為索引的觀看次數 `Series`。
- `get_video_views(view_series, video_name)`：回傳指定影片的觀看次數。
- `get_average_views(view_series)`：回傳平均觀看次數。
- `get_highest_views(view_series)`：回傳最高觀看次數。
- `get_popular_views(view_series, view_limit)`：回傳大於等於 `view_limit` 的觀看次數 `Series`。
- `get_popular_video_names(view_series, view_limit)`：回傳大於等於 `view_limit` 的影片名 list。

## 回傳格式提醒

建立與篩選結果請回傳 Pandas `Series`。

影片名清單請回傳 Python list。

平均觀看次數、最高觀看次數請回傳一個數字。

## 提示

建立 Series：

```python
pd.Series(views, index=video_names)
```

條件篩選：

```python
view_series[view_series >= view_limit]
```

取得索引名稱：

```python
view_series.index.tolist()
```

## 常見錯誤

如果你看到：

```text
ModuleNotFoundError: No module named 'pandas'
```

通常代表目前 Python 環境找不到 Pandas。請確認你已經切換到課程指定的 Conda 環境。

如果你看到：

```text
NotImplementedError
```

代表該函式還沒有完成。請回到 `main_pandas_series.py`，把 `raise NotImplementedError(...)` 改成你的程式。
