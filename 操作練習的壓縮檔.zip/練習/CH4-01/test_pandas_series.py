import pandas as pd

from main_pandas_series import (
    create_view_series,
    get_average_views,
    get_highest_views,
    get_popular_video_names,
    get_popular_views,
    get_video_views,
)


def get_sample_data():
    video_names = ["旅遊 Vlog", "美食開箱", "遊戲實況", "音樂 MV", "科技評測"]
    views = [1200, 3000, 800, 2000, 500]
    return video_names, views


def get_sample_series():
    video_names, views = get_sample_data()
    return pd.Series(views, index=video_names)


def test_create_view_series() -> bool:
    print("---------------------------------")
    video_names, views = get_sample_data()
    actual = create_view_series(video_names, views)
    expected = pd.Series(views, index=video_names)

    print("輸入：影片名與觀看次數")
    print(f"預期：\n{expected}")
    print(f"實際：\n{actual}")

    if isinstance(actual, pd.Series) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_video_views() -> bool:
    print("---------------------------------")
    actual = get_video_views(get_sample_series(), "美食開箱")
    expected = 3000

    print("輸入：美食開箱")
    print(f"預期觀看次數：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_average_views() -> bool:
    print("---------------------------------")
    actual = get_average_views(get_sample_series())
    expected = 1500.0

    print("輸入：5 部影片觀看次數")
    print(f"預期平均：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_highest_views() -> bool:
    print("---------------------------------")
    actual = get_highest_views(get_sample_series())
    expected = 3000

    print("輸入：5 部影片觀看次數")
    print(f"預期最高觀看次數：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_popular_views() -> bool:
    print("---------------------------------")
    actual = get_popular_views(get_sample_series(), 1200)
    expected = pd.Series([1200, 3000, 2000], index=["旅遊 Vlog", "美食開箱", "音樂 MV"])

    print("輸入：觀看次數 1200 以上")
    print(f"預期：\n{expected}")
    print(f"實際：\n{actual}")

    if isinstance(actual, pd.Series) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_popular_video_names() -> bool:
    print("---------------------------------")
    actual = get_popular_video_names(get_sample_series(), 1200)
    expected = ["旅遊 Vlog", "美食開箱", "音樂 MV"]

    print("輸入：觀看次數 1200 以上")
    print(f"預期影片：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_view_series),
        run_test(test_get_video_views),
        run_test(test_get_average_views),
        run_test(test_get_highest_views),
        run_test(test_get_popular_views),
        run_test(test_get_popular_video_names),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
