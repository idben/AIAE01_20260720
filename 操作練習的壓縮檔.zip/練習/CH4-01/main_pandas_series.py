import pandas as pd


def create_view_series(video_names, views):
    # 基礎：請建立以 video_names 為索引、views 為資料的 Series
    raise NotImplementedError("請完成 create_view_series")


def get_video_views(view_series, video_name):
    # 基礎：請用影片名從 Series 取出觀看次數
    raise NotImplementedError("請完成 get_video_views")


def get_average_views(view_series):
    # 基礎：請回傳平均觀看次數
    raise NotImplementedError("請完成 get_average_views")


def get_highest_views(view_series):
    # 基礎：請回傳最高觀看次數
    raise NotImplementedError("請完成 get_highest_views")


def get_popular_views(view_series, view_limit):
    # 應用：請回傳大於等於 view_limit 的觀看次數 Series
    raise NotImplementedError("請完成 get_popular_views")


def get_popular_video_names(view_series, view_limit):
    # 應用：請回傳大於等於 view_limit 的影片名 list
    raise NotImplementedError("請完成 get_popular_video_names")
