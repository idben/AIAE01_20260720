# CH2-02 NumPy 商品銷售練習

這個練習會讓你用 NumPy 同時處理商品價格與銷售數量。

CH2-01 主要練習單一成績陣列。這一題會往前一步：你會拿兩個長度相同的一維陣列做對位運算，例如「單價 × 數量」。

你主要修改：

```text
main_numpy_prices.py
```

測試檔：

```text
test_numpy_prices.py
```

完成後，在這個資料夾中執行：

```bash
python test_numpy_prices.py
```

## 練習目標

請完成下列函式：

- `create_price_array(prices)`：把 Python list 轉成 NumPy 陣列。
- `create_quantity_array(quantities)`：把銷售數量 list 轉成 NumPy 陣列。
- `calculate_sales_amounts(price_array, quantity_array)`：用單價乘上數量，算出每個商品的銷售金額。
- `get_sales_at_least(sales_amounts, amount_limit)`：回傳大於等於指定金額的銷售金額。
- `get_sales_summary(sales_amounts)`：回傳平均、最高、最低、總和。
- `apply_discount_to_prices(price_array, discount_rate)`：計算折扣後單價。
- `calculate_discount_sales(discount_prices, quantity_array)`：用折扣後單價重新計算銷售金額。

## 回傳格式提醒

`get_sales_summary()` 請回傳 dict：

```python
{
    "average": ...,
    "highest": ...,
    "lowest": ...,
    "total": ...,
}
```

## 難度提醒

這一題不是只把成績換成價格。你需要注意兩個陣列的位置要互相對應：

```text
第 0 個價格 × 第 0 個數量
第 1 個價格 × 第 1 個數量
第 2 個價格 × 第 2 個數量
```

先確認兩個陣列長度相同，再做整批乘法。

## 常見錯誤

如果測試顯示 `NotImplementedError`，代表函式還沒有完成。

如果出現 `ModuleNotFoundError: No module named 'numpy'`，請確認你已經切換到課程指定的 Conda 環境。
