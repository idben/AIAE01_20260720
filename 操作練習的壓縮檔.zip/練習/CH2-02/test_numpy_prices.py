import numpy as np

from main_numpy_prices import (
    apply_discount_to_prices,
    calculate_discount_sales,
    calculate_sales_amounts,
    create_price_array,
    create_quantity_array,
    get_sales_at_least,
    get_sales_summary,
)


def test_create_price_array() -> bool:
    print("---------------------------------")
    actual = create_price_array([120, 80, 200, 150, 60])
    expected = [120, 80, 200, 150, 60]

    print("輸入價格：[120, 80, 200, 150, 60]")
    print(f"實際型別：{type(actual)}")
    print(f"實際內容：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_create_quantity_array() -> bool:
    print("---------------------------------")
    actual = create_quantity_array([3, 5, 2, 4, 6])
    expected = [3, 5, 2, 4, 6]

    print("輸入數量：[3, 5, 2, 4, 6]")
    print(f"實際型別：{type(actual)}")
    print(f"實際內容：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_calculate_sales_amounts() -> bool:
    print("---------------------------------")
    price_array = np.array([120, 80, 200, 150, 60])
    quantity_array = np.array([3, 5, 2, 4, 6])
    actual = calculate_sales_amounts(price_array, quantity_array)
    expected = [360, 400, 400, 600, 360]

    print("輸入價格：[120, 80, 200, 150, 60]")
    print("輸入數量：[3, 5, 2, 4, 6]")
    print(f"預期銷售金額：{expected}")
    print(f"實際銷售金額：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_sales_at_least() -> bool:
    print("---------------------------------")
    sales_amounts = np.array([360, 400, 400, 600, 360])
    actual = get_sales_at_least(sales_amounts, 400)
    expected = [400, 400, 600]

    print("輸入銷售金額：[360, 400, 400, 600, 360]")
    print(f"預期：大於等於 400 的銷售金額是 {expected}")
    print(f"實際：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_sales_summary() -> bool:
    print("---------------------------------")
    sales_amounts = np.array([360, 400, 400, 600, 360])
    actual = get_sales_summary(sales_amounts)

    print("輸入銷售金額：[360, 400, 400, 600, 360]")
    print("預期：平均 424.0、最高 600、最低 360、總和 2120")
    print(f"實際：{actual}")

    average_is_correct = abs(actual.get("average") - 424.0) < 0.001

    if (
        average_is_correct
        and actual.get("highest") == 600
        and actual.get("lowest") == 360
        and actual.get("total") == 2120
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_apply_discount_to_prices() -> bool:
    print("---------------------------------")
    price_array = np.array([120, 80, 200, 150, 60])
    actual = apply_discount_to_prices(price_array, 0.8)
    expected = [96.0, 64.0, 160.0, 120.0, 48.0]

    print("輸入價格：[120, 80, 200, 150, 60]，打 8 折")
    print(f"預期折扣後單價：{expected}")
    print(f"實際折扣後單價：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and np.allclose(actual, expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_calculate_discount_sales() -> bool:
    print("---------------------------------")
    discount_prices = np.array([96.0, 64.0, 160.0, 120.0, 48.0])
    quantity_array = np.array([3, 5, 2, 4, 6])
    actual = calculate_discount_sales(discount_prices, quantity_array)
    expected = [288.0, 320.0, 320.0, 480.0, 288.0]

    print("輸入折扣後單價：[96.0, 64.0, 160.0, 120.0, 48.0]")
    print("輸入數量：[3, 5, 2, 4, 6]")
    print(f"預期折扣後銷售金額：{expected}")
    print(f"實際折扣後銷售金額：{actual.tolist()}")

    if isinstance(actual, np.ndarray) and np.allclose(actual, expected):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_price_array),
        run_test(test_create_quantity_array),
        run_test(test_calculate_sales_amounts),
        run_test(test_get_sales_at_least),
        run_test(test_get_sales_summary),
        run_test(test_apply_discount_to_prices),
        run_test(test_calculate_discount_sales),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
