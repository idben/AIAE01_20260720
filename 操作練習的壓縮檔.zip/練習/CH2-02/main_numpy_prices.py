import numpy as np


def create_price_array(prices):
    # 請把 Python list 轉成 NumPy 陣列後回傳
    raise NotImplementedError("請完成 create_price_array")


def create_quantity_array(quantities):
    # 請把銷售數量 list 轉成 NumPy 陣列後回傳
    raise NotImplementedError("請完成 create_quantity_array")


def calculate_sales_amounts(price_array, quantity_array):
    # 請用單價乘上數量，回傳每個商品的銷售金額
    raise NotImplementedError("請完成 calculate_sales_amounts")


def get_sales_at_least(sales_amounts, amount_limit):
    # 請回傳大於等於 amount_limit 的銷售金額
    raise NotImplementedError("請完成 get_sales_at_least")


def get_sales_summary(sales_amounts):
    # 請回傳一個 dict，key 為 average、highest、lowest、total
    # 分別是平均、最高、最低、總和
    raise NotImplementedError("請完成 get_sales_summary")


def apply_discount_to_prices(price_array, discount_rate):
    # 請回傳折扣後單價，例如 discount_rate 為 0.8 表示打 8 折
    raise NotImplementedError("請完成 apply_discount_to_prices")


def calculate_discount_sales(discount_prices, quantity_array):
    # 請用折扣後單價乘上數量，回傳折扣後銷售金額
    raise NotImplementedError("請完成 calculate_discount_sales")
