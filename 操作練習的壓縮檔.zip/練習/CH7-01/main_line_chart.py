import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt


def get_weekly_sales_data():
    # 基礎：請回傳 (days, sales)
    raise NotImplementedError("請完成 get_weekly_sales_data")


def create_weekly_sales_chart(days, sales):
    # 基礎：請建立折線圖，並回傳 (fig, ax)
    # 圖表標題為「一週飲料店銷售額」，x 軸名稱為「星期」，y 軸名稱為「銷售額」
    # 折線需帶有 marker 標記點，需顯示圖例，需顯示格線
    raise NotImplementedError("請完成 create_weekly_sales_chart")


def save_weekly_sales_chart(output_path):
    # 應用：請建立折線圖、儲存圖片，並回傳 output_path
    raise NotImplementedError("請完成 save_weekly_sales_chart")
