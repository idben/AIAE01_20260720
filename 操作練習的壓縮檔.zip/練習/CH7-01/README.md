# CH7-01 Matplotlib 折線圖練習

這是第 7 章的第一個練習。你會用一週銷售資料畫出折線圖，並把圖片存成檔案。

你主要修改：

```text
main_line_chart.py
```

測試檔：

```text
test_line_chart.py
```

完成後，在這個資料夾中執行：

```bash
python test_line_chart.py
```

## 難度定位

基礎：這題練習 Matplotlib 的折線圖、標題、座標軸、格線、圖例和圖片存檔。

## 練習目標

請完成下列函式：

- `get_weekly_sales_data()`：回傳星期與銷售額兩個 list。
- `create_weekly_sales_chart(days, sales)`：建立折線圖，回傳 `(fig, ax)`。
- `save_weekly_sales_chart(output_path)`：建立圖表並存成圖片，回傳輸出路徑。

## 圖表要求

- 使用折線圖。
- x 軸資料是 `["週一", "週二", "週三", "週四", "週五", "週六", "週日"]`。
- y 軸資料是 `[3200, 3500, 3300, 4100, 4800, 5200, 5000]`。
- 圖表標題是 `一週飲料店銷售額`。
- x 軸名稱是 `星期`。
- y 軸名稱是 `銷售額`。
- 折線要有 marker，例如 `marker="o"`。
- 要顯示格線與圖例。

## 提示

建立圖表時可以使用：

```python
fig, ax = plt.subplots(figsize=(8, 4))
ax.plot(days, sales, marker="o", label="每日銷售額")
```

儲存圖片前可以使用：

```python
fig.tight_layout()
fig.savefig(output_path)
```

儲存後記得關閉圖表：

```python
plt.close(fig)
```
