from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from main_line_chart import (
    create_weekly_sales_chart,
    get_weekly_sales_data,
    save_weekly_sales_chart,
)


OUTPUT_PATH = Path(__file__).parent / "weekly_sales.png"


def test_get_weekly_sales_data() -> bool:
    print("---------------------------------")
    actual_days, actual_sales = get_weekly_sales_data()
    expected_days = ["週一", "週二", "週三", "週四", "週五", "週六", "週日"]
    expected_sales = [3200, 3500, 3300, 4100, 4800, 5200, 5000]

    print(f"預期星期：{expected_days}")
    print(f"實際星期：{actual_days}")
    print(f"預期銷售額：{expected_sales}")
    print(f"實際銷售額：{actual_sales}")

    if actual_days == expected_days and actual_sales == expected_sales:
        print("通過")
        return True

    print("失敗")
    return False


def test_create_weekly_sales_chart() -> bool:
    print("---------------------------------")
    days = ["週一", "週二", "週三", "週四", "週五", "週六", "週日"]
    sales = [3200, 3500, 3300, 4100, 4800, 5200, 5000]
    fig, ax = create_weekly_sales_chart(days, sales)

    line_count = len(ax.lines)
    line = ax.lines[0] if line_count > 0 else None
    actual_y = list(line.get_ydata()) if line is not None else []
    has_marker = line is not None and line.get_marker() not in [None, "", "None"]
    has_legend = ax.get_legend() is not None
    has_grid = any(gridline.get_visible() for gridline in ax.get_ygridlines())

    print(f"圖表標題：{ax.get_title()}")
    print(f"x 軸名稱：{ax.get_xlabel()}")
    print(f"y 軸名稱：{ax.get_ylabel()}")
    print(f"折線數量：{line_count}")
    print(f"折線 y 值：{actual_y}")

    ok = (
        fig is not None
        and ax.get_title() == "一週飲料店銷售額"
        and ax.get_xlabel() == "星期"
        and ax.get_ylabel() == "銷售額"
        and line_count == 1
        and actual_y == sales
        and has_marker
        and has_legend
        and has_grid
    )

    plt.close(fig)

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def test_save_weekly_sales_chart() -> bool:
    print("---------------------------------")
    if OUTPUT_PATH.exists():
        OUTPUT_PATH.unlink()

    actual_path = save_weekly_sales_chart(OUTPUT_PATH)

    print(f"預期圖片路徑：{OUTPUT_PATH}")
    print(f"實際回傳路徑：{actual_path}")
    print(f"圖片是否存在：{OUTPUT_PATH.exists()}")

    if actual_path == OUTPUT_PATH and OUTPUT_PATH.exists() and OUTPUT_PATH.stat().st_size > 0:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_get_weekly_sales_data),
        run_test(test_create_weekly_sales_chart),
        run_test(test_save_weekly_sales_chart),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
