import pandas as pd


def load_orders_csv(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV 檔案，內容照實回傳為 DataFrame
    raise NotImplementedError("請完成 load_orders_csv")


def prepare_sales_data(orders_df):
    # 基礎：請回傳新增小計欄位後的 DataFrame
    # 小計 = 數量 * 單價，不要改到傳入的 orders_df
    raise NotImplementedError("請完成 prepare_sales_data")


def get_product_summary(orders_df):
    # 應用：請依照商品與分類分組，用 agg() 產生商品銷售摘要
    # 回傳欄位為 商品、分類、總數量、平均數量、訂單筆數、最高單筆銷售額、總銷售額
    # 依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_product_summary")


def get_category_summary(orders_df):
    # 應用：請依照分類分組，產生分類銷售摘要
    # 回傳欄位為 分類、總數量、訂單筆數、總銷售額，依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_category_summary")


def get_high_value_products(orders_df, min_sales):
    # 進階：請回傳總銷售額大於等於 min_sales 的商品摘要
    # 可先呼叫 get_product_summary()，再依總銷售額篩選
    raise NotImplementedError("請完成 get_high_value_products")


def get_summary_report(orders_df):
    # 整合：請回傳 dict，含三個 key：
    #   row_count：整體訂單筆數
    #   total_sales：所有訂單的總銷售額
    #   top_product：總銷售額最高的商品名稱
    raise NotImplementedError("請完成 get_summary_report")
