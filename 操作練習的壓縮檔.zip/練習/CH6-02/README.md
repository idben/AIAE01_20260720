# CH6-02 Pandas agg 統計摘要練習

這是第 6 章的第二個練習。你會把樂器行的訂單明細整理成摘要表，練習使用 `agg()` 一次產生多個統計欄位。

你主要修改：

```text
main_instrument_summary.py
```

測試檔：

```text
test_instrument_summary.py
```

資料檔：

```text
data/instruments.csv
```

完成後，在這個資料夾中執行：

```bash
python test_instrument_summary.py
```

## 難度定位

應用：你不只要做分組加總，還要同時產生總數量、平均數量、訂單筆數、最高單筆銷售額和總銷售額。

## 練習目標

請完成下列函式：

- `load_orders_csv(csv_path)`：讀取 CSV，回傳 DataFrame。
- `prepare_sales_data(orders_df)`：新增 `小計` 欄位。
- `get_product_summary(orders_df)`：依照 `商品` 與 `分類` 分組，產生商品銷售摘要。
- `get_category_summary(orders_df)`：依照 `分類` 分組，產生分類銷售摘要。
- `get_high_value_products(orders_df, min_sales)`：回傳總銷售額大於等於 `min_sales` 的商品摘要。
- `get_summary_report(orders_df)`：回傳一個 dict，包含整體訂單筆數、總銷售額、銷售額最高商品。

## 商品摘要欄位

`get_product_summary()` 請回傳欄位：

```text
商品, 分類, 總數量, 平均數量, 訂單筆數, 最高單筆銷售額, 總銷售額
```

結果請依照 `總銷售額` 從高到低排序。

## 分類摘要欄位

`get_category_summary()` 請回傳欄位：

```text
分類, 總數量, 訂單筆數, 總銷售額
```

結果請依照 `總銷售額` 從高到低排序。

## 資料欄位

`data/instruments.csv` 有下列欄位：

- `訂單編號`
- `商品`
- `分類`
- `數量`
- `單價`

## 提示

`agg()` 可以直接指定輸出欄位名稱：

```python
summary_df = orders_df.groupby("商品").agg(
    總數量=("數量", "sum"),
    訂單筆數=("訂單編號", "count"),
)
```

如果要同時依照商品與分類分組，可以傳入 list：

```python
orders_df.groupby(["商品", "分類"])
```

## 常見錯誤

`get_high_value_products()` 可以先呼叫你寫好的 `get_product_summary()`，再用條件篩選。這樣比較不容易重複寫太多相同程式。

如果看到 `FileNotFoundError`，請確認你是在 `CH6-02` 資料夾中執行測試檔，或確認 `data/instruments.csv` 是否存在。
