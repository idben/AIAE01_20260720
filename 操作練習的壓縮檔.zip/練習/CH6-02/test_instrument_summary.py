from pathlib import Path

import pandas as pd

from main_instrument_summary import (
    get_category_summary,
    get_high_value_products,
    get_product_summary,
    get_summary_report,
    load_orders_csv,
    prepare_sales_data,
)


DATA_PATH = Path(__file__).parent / "data" / "instruments.csv"


def get_orders_df():
    return pd.DataFrame({
        "訂單編號": [301, 302, 303, 304, 305, 306, 307, 308],
        "商品": ["木吉他", "烏克麗麗", "木吉他", "口琴", "烏克麗麗", "節拍器", "口琴", "木吉他"],
        "分類": ["弦樂器", "弦樂器", "弦樂器", "管樂器", "弦樂器", "打擊樂器", "管樂器", "弦樂器"],
        "數量": [2, 4, 2, 6, 4, 5, 4, 2],
        "單價": [3200, 900, 3200, 350, 900, 480, 350, 3200],
    })


def get_prepared_df():
    orders_df = get_orders_df()
    orders_df["小計"] = [6400, 3600, 6400, 2100, 3600, 2400, 1400, 6400]
    return orders_df


def test_load_orders_csv() -> bool:
    print("---------------------------------")
    actual = load_orders_csv(DATA_PATH)
    expected = get_orders_df()

    print("預期讀取 CSV 後的資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_prepare_sales_data() -> bool:
    print("---------------------------------")
    original_df = load_orders_csv(DATA_PATH)
    actual = prepare_sales_data(original_df)
    expected = get_prepared_df()

    print("預期新增小計後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "小計" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_product_summary() -> bool:
    print("---------------------------------")
    actual = get_product_summary(load_orders_csv(DATA_PATH))
    expected = pd.DataFrame({
        "商品": ["木吉他", "烏克麗麗", "口琴", "節拍器"],
        "分類": ["弦樂器", "弦樂器", "管樂器", "打擊樂器"],
        "總數量": [6, 8, 10, 5],
        "平均數量": [2.0, 4.0, 5.0, 5.0],
        "訂單筆數": [3, 2, 2, 1],
        "最高單筆銷售額": [6400, 3600, 2100, 2400],
        "總銷售額": [19200, 7200, 3500, 2400],
    }, index=[1, 2, 0, 3])

    print("預期商品摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_category_summary() -> bool:
    print("---------------------------------")
    actual = get_category_summary(load_orders_csv(DATA_PATH))
    expected = pd.DataFrame({
        "分類": ["弦樂器", "管樂器", "打擊樂器"],
        "總數量": [14, 10, 5],
        "訂單筆數": [5, 2, 1],
        "總銷售額": [26400, 3500, 2400],
    }, index=[0, 2, 1])

    print("預期分類摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_high_value_products() -> bool:
    print("---------------------------------")
    actual = get_high_value_products(load_orders_csv(DATA_PATH), 6000)
    expected_products = ["木吉他", "烏克麗麗"]
    actual_products = actual["商品"].tolist()

    print(f"預期總銷售額大於等於 6000 的商品：{expected_products}")
    print(f"實際：{actual_products}")

    if isinstance(actual, pd.DataFrame) and actual_products == expected_products:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_summary_report() -> bool:
    print("---------------------------------")
    actual = get_summary_report(load_orders_csv(DATA_PATH))
    expected = {
        "row_count": 8,
        "total_sales": 32300,
        "top_product": "木吉他",
    }

    print("預期整體摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_orders_csv),
        run_test(test_prepare_sales_data),
        run_test(test_get_product_summary),
        run_test(test_get_category_summary),
        run_test(test_get_high_value_products),
        run_test(test_get_summary_report),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
