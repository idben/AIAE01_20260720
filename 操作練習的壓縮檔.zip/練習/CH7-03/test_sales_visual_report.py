from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd

from main_sales_visual_report import (
    add_sales_amount,
    build_visual_report,
    clean_orders,
    create_daily_sales_line_chart,
    create_order_amount_histogram,
    create_product_sales_bar_chart,
    get_daily_sales,
    get_product_sales,
    load_orders,
)


BASE_DIR = Path(__file__).parent
CSV_PATH = BASE_DIR / "data" / "drink_orders.csv"
OUTPUT_DIR = BASE_DIR / "charts"


def get_expected_loaded_df():
    return pd.DataFrame({
        "訂單編號": [501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512],
        "日期": [
            "2026-06-01", "2026-06-01", "2026-06-02", "2026-06-02",
            "2026-06-03", "2026-06-03", "2026-06-04", "2026-06-04",
            "2026-06-05", "2026-06-05", "2026-06-06", "2026-06-06",
        ],
        "商品": ["紅茶", "奶茶", "紅茶", "綠茶", "可可", "奶茶", "檸檬汁", "綠茶", "紅茶", "可可", "奶茶", "紅茶"],
        "數量": [2.0, 1.0, 3.0, 2.0, 4.0, 2.0, 3.0, 1.0, 1.0, None, 3.0, 2.0],
        "單價": [30.0, 45.0, 30.0, 35.0, 50.0, 45.0, 40.0, 35.0, 30.0, 50.0, 45.0, None],
    })


def get_expected_cleaned_df():
    return pd.DataFrame({
        "訂單編號": [501, 502, 503, 504, 505, 506, 507, 508, 509, 511],
        "日期": [
            "2026-06-01", "2026-06-01", "2026-06-02", "2026-06-02",
            "2026-06-03", "2026-06-03", "2026-06-04", "2026-06-04",
            "2026-06-05", "2026-06-06",
        ],
        "商品": ["紅茶", "奶茶", "紅茶", "綠茶", "可可", "奶茶", "檸檬汁", "綠茶", "紅茶", "奶茶"],
        "數量": [2.0, 1.0, 3.0, 2.0, 4.0, 2.0, 3.0, 1.0, 1.0, 3.0],
        "單價": [30.0, 45.0, 30.0, 35.0, 50.0, 45.0, 40.0, 35.0, 30.0, 45.0],
    }, index=[0, 1, 2, 3, 4, 5, 6, 7, 8, 10])


def get_expected_with_sales_df():
    cleaned_df = get_expected_cleaned_df()
    cleaned_df["銷售額"] = [60.0, 45.0, 90.0, 70.0, 200.0, 90.0, 120.0, 35.0, 30.0, 135.0]
    return cleaned_df


def get_expected_daily_sales_df():
    return pd.DataFrame({
        "日期": ["2026-06-01", "2026-06-02", "2026-06-03", "2026-06-04", "2026-06-05", "2026-06-06"],
        "總銷售額": [105.0, 160.0, 290.0, 155.0, 30.0, 135.0],
    })


def get_expected_product_sales_df():
    return pd.DataFrame({
        "商品": ["奶茶", "可可", "紅茶", "檸檬汁", "綠茶"],
        "總銷售額": [270.0, 200.0, 180.0, 120.0, 105.0],
    }, index=[1, 0, 3, 2, 4])


def test_load_orders() -> bool:
    print("---------------------------------")
    actual = load_orders(CSV_PATH)
    expected = get_expected_loaded_df()

    print("預期讀取資料前五列：")
    print(expected.head())
    print("實際前五列：")
    print(actual.head())

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_clean_orders() -> bool:
    print("---------------------------------")
    original_df = get_expected_loaded_df()
    actual = clean_orders(original_df)
    expected = get_expected_cleaned_df()

    print("預期清理後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = len(original_df) == 12

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_sales_amount() -> bool:
    print("---------------------------------")
    original_df = get_expected_cleaned_df()
    actual = add_sales_amount(original_df)
    expected = get_expected_with_sales_df()

    print("預期新增銷售額後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "銷售額" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_daily_sales() -> bool:
    print("---------------------------------")
    actual = get_daily_sales(get_expected_with_sales_df())
    expected = get_expected_daily_sales_df()

    print("預期每日銷售額：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_product_sales() -> bool:
    print("---------------------------------")
    actual = get_product_sales(get_expected_with_sales_df())
    expected = get_expected_product_sales_df()

    print("預期商品銷售額：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_create_daily_sales_line_chart() -> bool:
    print("---------------------------------")
    fig, ax = create_daily_sales_line_chart(get_expected_daily_sales_df())
    line = ax.lines[0] if len(ax.lines) > 0 else None
    actual_y = list(line.get_ydata()) if line is not None else []

    print(f"圖表標題：{ax.get_title()}")
    print(f"折線 y 值：{actual_y}")

    ok = (
        ax.get_title() == "每日銷售額"
        and ax.get_xlabel() == "日期"
        and ax.get_ylabel() == "總銷售額"
        and actual_y == [105.0, 160.0, 290.0, 155.0, 30.0, 135.0]
    )
    plt.close(fig)

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def test_create_product_sales_bar_chart() -> bool:
    print("---------------------------------")
    fig, ax = create_product_sales_bar_chart(get_expected_product_sales_df())
    bar_heights = [bar.get_height() for bar in ax.patches]

    print(f"圖表標題：{ax.get_title()}")
    print(f"長條高度：{bar_heights}")

    ok = (
        ax.get_title() == "商品總銷售額"
        and ax.get_xlabel() == "商品"
        and ax.get_ylabel() == "總銷售額"
        and bar_heights == [270.0, 200.0, 180.0, 120.0, 105.0]
    )
    plt.close(fig)

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def test_create_order_amount_histogram() -> bool:
    print("---------------------------------")
    fig, ax = create_order_amount_histogram(get_expected_with_sales_df())

    print(f"圖表標題：{ax.get_title()}")
    print(f"直方圖區塊數量：{len(ax.patches)}")

    ok = (
        ax.get_title() == "訂單銷售額分布"
        and ax.get_xlabel() == "銷售額"
        and ax.get_ylabel() == "訂單筆數"
        and len(ax.patches) > 0
    )
    plt.close(fig)

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def test_build_visual_report() -> bool:
    print("---------------------------------")
    if OUTPUT_DIR.exists():
        for path in OUTPUT_DIR.glob("*.png"):
            path.unlink()

    actual = build_visual_report(CSV_PATH, OUTPUT_DIR)

    print("預期完整報表包含 daily_sales、product_sales、total_sales、top_product、chart_paths")
    print("實際：")
    print(actual)

    required_keys = {"daily_sales", "product_sales", "total_sales", "top_product", "chart_paths"}
    has_required_keys = isinstance(actual, dict) and set(actual.keys()) == required_keys

    if not has_required_keys:
        print("失敗")
        return False

    expected_paths = [
        OUTPUT_DIR / "daily_sales.png",
        OUTPUT_DIR / "product_sales.png",
        OUTPUT_DIR / "order_amount_histogram.png",
    ]
    chart_paths_ok = actual["chart_paths"] == expected_paths
    files_exist = all(path.exists() and path.stat().st_size > 0 for path in expected_paths)

    ok = (
        actual["daily_sales"].equals(get_expected_daily_sales_df())
        and actual["product_sales"].equals(get_expected_product_sales_df())
        and actual["total_sales"] == 875.0
        and actual["top_product"] == "奶茶"
        and chart_paths_ok
        and files_exist
    )

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_orders),
        run_test(test_clean_orders),
        run_test(test_add_sales_amount),
        run_test(test_get_daily_sales),
        run_test(test_get_product_sales),
        run_test(test_create_daily_sales_line_chart),
        run_test(test_create_product_sales_bar_chart),
        run_test(test_create_order_amount_histogram),
        run_test(test_build_visual_report),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
