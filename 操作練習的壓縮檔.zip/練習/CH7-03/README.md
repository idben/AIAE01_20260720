# CH7-03 銷售資料視覺化整合練習

這是第 7 章的第三個練習。你會讀取 CSV，清理缺失資料，建立每日銷售摘要、商品摘要，最後輸出多張圖表與分析結果。

你主要修改：

```text
main_sales_visual_report.py
```

測試檔：

```text
test_sales_visual_report.py
```

資料檔：

```text
data/drink_orders.csv
```

完成後，在這個資料夾中執行：

```bash
python test_sales_visual_report.py
```

## 難度定位

挑戰：這題會串起 CSV 讀取、缺失值處理、新增欄位、分組統計、折線圖、長條圖、直方圖和完整報表輸出。

## 練習目標

請完成下列函式：

- `load_orders(csv_path)`：讀取 CSV。
- `clean_orders(orders_df)`：移除 `數量` 或 `單價` 缺失的資料，回傳新的 DataFrame。
- `add_sales_amount(orders_df)`：新增 `銷售額` 欄位。
- `get_daily_sales(orders_df)`：依照 `日期` 分組，計算每日總銷售額。
- `get_product_sales(orders_df)`：依照 `商品` 分組，計算商品總銷售額，並由高到低排序。
- `create_daily_sales_line_chart(daily_sales_df)`：建立每日銷售額折線圖。
- `create_product_sales_bar_chart(product_sales_df)`：建立商品總銷售額長條圖。
- `create_order_amount_histogram(orders_df)`：建立訂單銷售額直方圖。
- `build_visual_report(csv_path, output_dir)`：完成整個流程，輸出圖片並回傳報表 dict。

## 報表格式

`build_visual_report()` 請回傳：

```python
{
    "daily_sales": daily_sales_df,
    "product_sales": product_sales_df,
    "total_sales": 總銷售額,
    "top_product": 銷售額最高商品,
    "chart_paths": [daily_chart_path, product_chart_path, histogram_path],
}
```

## 圖表輸出檔名

請在 `output_dir` 底下產生三個圖片檔：

```text
daily_sales.png
product_sales.png
order_amount_histogram.png
```

## 提示

移除缺失值時，只需要針對 `數量` 和 `單價`：

```python
cleaned_df = orders_df.dropna(subset=["數量", "單價"])
```

每日銷售額請依照 `日期` 排序，讓折線圖順序正確。

```python
daily_sales_df = daily_sales_df.sort_values("日期")
```

這題的重點不是把圖畫得很華麗，而是把資料整理、統計與視覺化流程串起來。
