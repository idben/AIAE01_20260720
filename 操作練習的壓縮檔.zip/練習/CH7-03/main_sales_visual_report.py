from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd


def load_orders(csv_path):
    # 基礎：請讀取 CSV，並回傳 DataFrame
    raise NotImplementedError("請完成 load_orders")


def clean_orders(orders_df):
    # 基礎：請移除數量或單價缺失的資料，並回傳新的 DataFrame
    # 不要改到傳入的 orders_df
    raise NotImplementedError("請完成 clean_orders")


def add_sales_amount(orders_df):
    # 基礎：請新增銷售額欄位，內容為 數量 * 單價
    # 不要改到傳入的 orders_df
    raise NotImplementedError("請完成 add_sales_amount")


def get_daily_sales(orders_df):
    # 應用：請依照日期分組，計算每日總銷售額
    # 回傳的欄位為 日期、總銷售額，並依日期由早到晚排序
    raise NotImplementedError("請完成 get_daily_sales")


def get_product_sales(orders_df):
    # 應用：請依照商品分組，計算商品總銷售額
    # 回傳的欄位為 商品、總銷售額，並依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_product_sales")


def create_daily_sales_line_chart(daily_sales_df):
    # 應用：請建立每日銷售額折線圖，並回傳 (fig, ax)
    # 圖表標題為「每日銷售額」，x 軸名稱為「日期」，y 軸名稱為「總銷售額」
    raise NotImplementedError("請完成 create_daily_sales_line_chart")


def create_product_sales_bar_chart(product_sales_df):
    # 應用：請建立商品銷售額長條圖，並回傳 (fig, ax)
    # 圖表標題為「商品總銷售額」，x 軸名稱為「商品」，y 軸名稱為「總銷售額」
    raise NotImplementedError("請完成 create_product_sales_bar_chart")


def create_order_amount_histogram(orders_df):
    # 應用：請建立訂單銷售額直方圖，並回傳 (fig, ax)
    # 圖表標題為「訂單銷售額分布」，x 軸名稱為「銷售額」，y 軸名稱為「訂單筆數」
    raise NotImplementedError("請完成 create_order_amount_histogram")


def build_visual_report(csv_path, output_dir):
    # 整合：請讀取、清理、統計、畫圖、存檔，並回傳完整報表 dict
    # 回傳 dict 的 key 為 daily_sales、product_sales、total_sales、top_product、chart_paths
    # daily_sales 為每日銷售額表，product_sales 為商品銷售額表
    # total_sales 為總銷售額，top_product 為銷售額最高的商品名稱
    # chart_paths 為三張圖的路徑，順序固定為 daily_sales.png、product_sales.png、order_amount_histogram.png
    raise NotImplementedError("請完成 build_visual_report")
