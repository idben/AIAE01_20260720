import numpy as np

from main_numpy_practice import (
    get_city_averages,
    get_day_averages,
    get_good_city_names,
    get_highest_aqi,
    get_lowest_aqi,
    get_unhealthy_values,
)


def get_sample_aqi():
    return np.array([
        [52, 68, 75, 60, 45],
        [120, 135, 110, 145, 100],
        [88, 95, 102, 80, 90],
        [42, 50, 55, 48, 40],
    ])


def values_are_close(actual, expected) -> bool:
    return np.allclose(actual, expected)


def test_get_city_averages() -> bool:
    print("---------------------------------")
    actual = get_city_averages(get_sample_aqi())
    expected = np.array([60.0, 122.0, 91.0, 47.0])

    print("輸入：4 城市、連續 5 天 AQI")
    print(f"預期每個城市平均：{expected}")
    print(f"實際每個城市平均：{actual}")

    if isinstance(actual, np.ndarray) and values_are_close(actual, expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_day_averages() -> bool:
    print("---------------------------------")
    actual = get_day_averages(get_sample_aqi())
    expected = np.array([75.5, 87.0, 85.5, 83.25, 68.75])

    print("輸入：4 城市、連續 5 天 AQI")
    print(f"預期每一天平均：{expected}")
    print(f"實際每一天平均：{actual}")

    if isinstance(actual, np.ndarray) and values_are_close(actual, expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_highest_aqi() -> bool:
    print("---------------------------------")
    actual = get_highest_aqi(get_sample_aqi())
    expected = 145

    print("輸入：4 城市、連續 5 天 AQI")
    print(f"預期最高 AQI：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_lowest_aqi() -> bool:
    print("---------------------------------")
    actual = get_lowest_aqi(get_sample_aqi())
    expected = 40

    print("輸入：4 城市、連續 5 天 AQI")
    print(f"預期最低 AQI：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_unhealthy_values() -> bool:
    print("---------------------------------")
    actual = get_unhealthy_values(get_sample_aqi(), 100)
    expected = np.array([120, 135, 110, 145, 100, 102])

    print("輸入：4 城市、連續 5 天 AQI，AQI 大於等於 100 算不健康")
    print(f"預期不健康數值：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_good_city_names() -> bool:
    print("---------------------------------")
    city_names = ["台北", "高雄", "台中", "花蓮"]
    actual = get_good_city_names(city_names, get_sample_aqi(), 70)
    expected = ["台北", "花蓮"]

    print("輸入：4 城市、連續 5 天 AQI，平均 AQI 小於等於 70 算空氣好")
    print(f"預期城市：{expected}")
    print(f"實際城市：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_get_city_averages),
        run_test(test_get_day_averages),
        run_test(test_get_highest_aqi),
        run_test(test_get_lowest_aqi),
        run_test(test_get_unhealthy_values),
        run_test(test_get_good_city_names),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
