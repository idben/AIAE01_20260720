# CH3-01 NumPy 空氣品質基礎練習

這是本章的基礎練習。你會先專注處理一張各城市的空氣品質 AQI 表，練熟二維陣列、`axis=0`、`axis=1`、最高最低值與簡單條件篩選。

表格的列(row)是城市，欄(column)是連續幾天的 AQI 數值。AQI 越高代表空氣越差。

這一題不會混入成績或銷售資料，目標是先把 AQI 表的方向看清楚。

你主要修改：

```text
main_numpy_practice.py
```

測試檔：

```text
test_numpy_practice.py
```

原則上不需要修改測試檔。你完成 `main_numpy_practice.py` 後，在這個資料夾中執行：

```bash
python test_numpy_practice.py
```

## 難度定位

基礎：看懂二維 AQI 表，完成單一步驟的 NumPy 計算。

## 練習目標

請完成下列函式：

- `get_city_averages(aqi_table)`：回傳每個城市的平均 AQI(沿 `axis=1`)。
- `get_day_averages(aqi_table)`：回傳每一天的平均 AQI(沿 `axis=0`)。
- `get_highest_aqi(aqi_table)`：回傳全部 AQI 中的最高值。
- `get_lowest_aqi(aqi_table)`：回傳全部 AQI 中的最低值。
- `get_unhealthy_values(aqi_table, limit)`：回傳大於等於 `limit` 的 AQI 數值陣列。
- `get_good_city_names(city_names, aqi_table, limit)`：回傳平均 AQI 小於等於 `limit` 的城市名稱 list。

## 回傳格式提醒

平均與篩選結果請回傳 NumPy 陣列。

例如：

```python
return aqi_table.mean(axis=1)
```

城市名稱請回傳 Python list。

例如：

```python
return ["台北", "花蓮"]
```

最高值與最低值請回傳一個數字。

## 提示

每個城市平均：

```python
aqi_table.mean(axis=1)
```

每一天平均：

```python
aqi_table.mean(axis=0)
```

大於等於 limit 的數值：

```python
aqi_table[aqi_table >= limit]
```

## 常見錯誤

如果你看到：

```text
ModuleNotFoundError: No module named 'numpy'
```

通常代表目前 Python 環境找不到 NumPy。請確認你已經切換到課程指定的 Conda 環境。

如果你看到：

```text
NotImplementedError
```

代表該函式還沒有完成。請回到 `main_numpy_practice.py`，把 `raise NotImplementedError(...)` 改成你的程式。

如果測試顯示結果方向相反，例如你算出 5 個數字，但預期是 4 個數字，通常是 `axis=0` 和 `axis=1` 用反了。你可以回到教材第 3 章，再對照「每一列」和「每一欄」的差異。

另外要注意，AQI 是越高越差，所以「不健康」用的是大於等於(`>=`)，「空氣好」用的是小於等於(`<=`)，方向和成績的及格判斷剛好相反。
