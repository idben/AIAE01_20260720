import numpy as np


def get_city_averages(aqi_table):
    # 基礎：aqi_table 是二維 AQI 陣列(列為城市，欄為連續幾天)
    # 請回傳每個城市的平均 AQI
    raise NotImplementedError("請完成 get_city_averages")


def get_day_averages(aqi_table):
    # 基礎：請回傳每一天的平均 AQI
    raise NotImplementedError("請完成 get_day_averages")


def get_highest_aqi(aqi_table):
    # 基礎：請回傳全部 AQI 中的最高值
    raise NotImplementedError("請完成 get_highest_aqi")


def get_lowest_aqi(aqi_table):
    # 基礎：請回傳全部 AQI 中的最低值
    raise NotImplementedError("請完成 get_lowest_aqi")


def get_unhealthy_values(aqi_table, limit):
    # 應用：AQI 越高代表空氣越差
    # aqi_table 是二維陣列，請回傳大於等於 limit 的 AQI 數值
    # 結果是把符合條件的值集合成的一維陣列
    raise NotImplementedError("請完成 get_unhealthy_values")


def get_good_city_names(city_names, aqi_table, limit):
    # 應用：請先計算每個城市的平均 AQI
    # 再回傳平均 AQI 小於等於 limit 的城市名稱 list(空氣好)
    raise NotImplementedError("請完成 get_good_city_names")
