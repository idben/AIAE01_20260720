from main_weather_report import (
    build_weather_summary,
    get_highest_temperature_record,
    get_hot_days,
)


def build_weather():
    return [
        {"日期": "06-01", "最高溫": 31, "最低溫": 24},
        {"日期": "06-02", "最高溫": 33, "最低溫": 25},
        {"日期": "06-03", "最高溫": 30, "最低溫": 24},
        {"日期": "06-04", "最高溫": 35, "最低溫": 27},
        {"日期": "06-05", "最高溫": 34, "最低溫": 26},
    ]


def test_get_highest_temperature_record():
    print("---------------------------------")
    weather = build_weather()
    expected = {"日期": "06-04", "最高溫": 35, "最低溫": 27}

    try:
        actual = get_highest_temperature_record(weather)
    except NotImplementedError as error:
        print("測試：找出最高溫那一天")
        print(error)
        print("失敗")
        return False

    print("測試：找出最高溫那一天")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_hot_days():
    print("---------------------------------")
    weather = build_weather()
    expected = ["06-02", "06-04", "06-05"]

    try:
        actual = get_hot_days(weather, 33)
    except NotImplementedError as error:
        print("測試：找出高溫日")
        print(error)
        print("失敗")
        return False

    print("測試：找出高溫日")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_build_weather_summary():
    print("---------------------------------")
    weather = build_weather()
    expected = "最高溫出現在 06-04，溫度是 35 度。共有 3 天最高溫大於等於 33 度。"

    try:
        actual = build_weather_summary(weather)
    except NotImplementedError as error:
        print("測試：建立天氣分析文字")
        print(error)
        print("失敗")
        return False

    print("測試：建立天氣分析文字")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def main():
    results = [
        test_get_highest_temperature_record(),
        test_get_hot_days(),
        test_build_weather_summary(),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
