def get_highest_temperature_record(weather):
    # 請回傳最高溫那一天的整筆資料
    raise NotImplementedError("請完成 get_highest_temperature_record")


def get_hot_days(weather, temperature_limit):
    # 請回傳最高溫大於等於 temperature_limit 的日期 list
    raise NotImplementedError("請完成 get_hot_days")


def build_weather_summary(weather):
    # 請回傳一段天氣分析文字，格式固定為兩句：
    # 「最高溫出現在 <日期>，溫度是 <溫度> 度。共有 <天數> 天最高溫大於等於 33 度。」
    # 天數固定以最高溫大於等於 33 度計算
    raise NotImplementedError("請完成 build_weather_summary")
