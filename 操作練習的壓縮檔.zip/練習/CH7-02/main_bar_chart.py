import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd


def load_orders(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV，內容照實回傳為 DataFrame
    raise NotImplementedError("請完成 load_orders")


def prepare_sales_data(orders_df):
    # 基礎：請新增銷售額欄位，並回傳新的 DataFrame
    # 銷售額欄位的內容為 數量 * 單價
    # 不要改到傳入的 orders_df
    raise NotImplementedError("請完成 prepare_sales_data")


def get_product_sales_summary(orders_df):
    # 應用：請依照商品分組，產生商品銷售摘要
    # 回傳的欄位為 商品、總數量、訂單筆數、總銷售額，並依總銷售額由高到低排序
    raise NotImplementedError("請完成 get_product_sales_summary")


def create_product_sales_bar_chart(summary_df):
    # 應用：請用商品摘要表建立長條圖，並回傳 (fig, ax)
    # 圖表標題為「各商品總銷售額」，x 軸名稱為「商品」，y 軸名稱為「總銷售額」，需顯示 y 軸格線
    raise NotImplementedError("請完成 create_product_sales_bar_chart")


def save_product_sales_bar_chart(csv_path, output_path):
    # 整合：請讀取 CSV、整理摘要、畫圖、存檔，並回傳 output_path
    raise NotImplementedError("請完成 save_product_sales_bar_chart")
