# CH7-02 Pandas 統計表與長條圖練習

這是第 7 章的第二個練習。你會先讀取一份訂單 CSV，用 Pandas 把訂單明細整理成商品銷售摘要，再把摘要表畫成長條圖。

你主要修改：

```text
main_bar_chart.py
```

測試檔：

```text
test_bar_chart.py
```

資料檔：

```text
data/orders.csv
```

完成後，在這個資料夾中執行：

```bash
python test_bar_chart.py
```

## 難度定位

應用：這題會把第 6 章的 CSV 讀取與分組統計接到第 7 章的長條圖，不只是單純畫固定數字。

## 練習目標

請完成下列函式：

- `load_orders(csv_path)`：讀取 `csv_path` 指定的 CSV，回傳 DataFrame。
- `prepare_sales_data(orders_df)`：新增 `銷售額` 欄位，內容為 `數量 * 單價`。
- `get_product_sales_summary(orders_df)`：依照 `商品` 分組，計算 `總數量`、`訂單筆數`、`總銷售額`，並依照 `總銷售額` 從高到低排序。
- `create_product_sales_bar_chart(summary_df)`：用商品摘要表畫長條圖，回傳 `(fig, ax)`。
- `save_product_sales_bar_chart(csv_path, output_path)`：讀取 CSV、整理摘要、畫圖、存檔，回傳輸出路徑。

## 資料欄位

`data/orders.csv` 有下列欄位：

- `訂單編號`
- `商品`
- `數量`
- `單價`

## 商品摘要欄位

```text
商品, 總數量, 訂單筆數, 總銷售額
```

結果請依照 `總銷售額` 從高到低排序。

## 圖表要求

- 使用長條圖。
- x 軸是 `商品`。
- y 軸是 `總銷售額`。
- 圖表標題是 `各商品總銷售額`。
- x 軸名稱是 `商品`。
- y 軸名稱是 `總銷售額`。
- 要顯示 y 軸格線。

## 提示

可以先完成第 6 章熟悉的分組統計：

```python
summary_df = (
    prepared_df
    .groupby("商品")
    .agg(
        總數量=("數量", "sum"),
        訂單筆數=("訂單編號", "count"),
        總銷售額=("銷售額", "sum"),
    )
    .reset_index()
)
```

再排序：

```python
summary_df = summary_df.sort_values("總銷售額", ascending=False)
```
