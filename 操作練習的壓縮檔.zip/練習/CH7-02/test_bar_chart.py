from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd

from main_bar_chart import (
    create_product_sales_bar_chart,
    get_product_sales_summary,
    load_orders,
    prepare_sales_data,
    save_product_sales_bar_chart,
)


DATA_PATH = Path(__file__).parent / "data" / "orders.csv"
OUTPUT_PATH = Path(__file__).parent / "product_sales.png"


def get_expected_orders_df():
    return pd.DataFrame({
        "訂單編號": [401, 402, 403, 404, 405, 406, 407, 408],
        "商品": ["紅茶", "奶茶", "紅茶", "綠茶", "可可", "奶茶", "檸檬汁", "綠茶"],
        "數量": [2, 1, 3, 2, 4, 2, 3, 1],
        "單價": [30, 45, 30, 35, 50, 45, 40, 35],
    })


def get_expected_prepared_df():
    orders_df = get_expected_orders_df()
    orders_df["銷售額"] = [60, 45, 90, 70, 200, 90, 120, 35]
    return orders_df


def get_expected_summary_df():
    return pd.DataFrame({
        "商品": ["可可", "紅茶", "奶茶", "檸檬汁", "綠茶"],
        "總數量": [4, 5, 3, 3, 3],
        "訂單筆數": [1, 2, 2, 1, 2],
        "總銷售額": [200, 150, 135, 120, 105],
    }, index=[0, 3, 1, 2, 4])


def test_load_orders() -> bool:
    print("---------------------------------")
    actual = load_orders(DATA_PATH)
    expected = get_expected_orders_df()

    print("預期訂單資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_prepare_sales_data() -> bool:
    print("---------------------------------")
    original_df = get_expected_orders_df()
    actual = prepare_sales_data(original_df)
    expected = get_expected_prepared_df()

    print("預期新增銷售額後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "銷售額" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_product_sales_summary() -> bool:
    print("---------------------------------")
    actual = get_product_sales_summary(get_expected_orders_df())
    expected = get_expected_summary_df()

    print("預期商品摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_create_product_sales_bar_chart() -> bool:
    print("---------------------------------")
    summary_df = get_expected_summary_df()
    fig, ax = create_product_sales_bar_chart(summary_df)

    bar_heights = [bar.get_height() for bar in ax.patches]
    x_labels = [label.get_text() for label in ax.get_xticklabels()]
    has_grid = any(gridline.get_visible() for gridline in ax.get_ygridlines())

    print(f"圖表標題：{ax.get_title()}")
    print(f"x 軸名稱：{ax.get_xlabel()}")
    print(f"y 軸名稱：{ax.get_ylabel()}")
    print(f"長條高度：{bar_heights}")
    print(f"x 軸標籤：{x_labels}")

    ok = (
        fig is not None
        and ax.get_title() == "各商品總銷售額"
        and ax.get_xlabel() == "商品"
        and ax.get_ylabel() == "總銷售額"
        and bar_heights == [200, 150, 135, 120, 105]
        and x_labels == ["可可", "紅茶", "奶茶", "檸檬汁", "綠茶"]
        and has_grid
    )

    plt.close(fig)

    if ok:
        print("通過")
        return True

    print("失敗")
    return False


def test_save_product_sales_bar_chart() -> bool:
    print("---------------------------------")
    if OUTPUT_PATH.exists():
        OUTPUT_PATH.unlink()

    actual_path = save_product_sales_bar_chart(DATA_PATH, OUTPUT_PATH)

    print(f"預期圖片路徑：{OUTPUT_PATH}")
    print(f"實際回傳路徑：{actual_path}")
    print(f"圖片是否存在：{OUTPUT_PATH.exists()}")

    if actual_path == OUTPUT_PATH and OUTPUT_PATH.exists() and OUTPUT_PATH.stat().st_size > 0:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_orders),
        run_test(test_prepare_sales_data),
        run_test(test_get_product_sales_summary),
        run_test(test_create_product_sales_bar_chart),
        run_test(test_save_product_sales_bar_chart),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
