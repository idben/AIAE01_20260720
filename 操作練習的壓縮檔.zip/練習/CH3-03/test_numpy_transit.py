import numpy as np

from main_numpy_transit import (
    get_best_route_index,
    get_best_route_name,
    get_fare_amounts,
    get_monthly_fare_totals,
    get_monthly_ride_totals,
    get_route_fare_totals,
    get_route_ride_totals,
    get_total_fare_amount,
    get_transit_report,
)


def get_sample_transit():
    ride_table = np.array([
        [800, 1200, 600, 400],
        [900, 1100, 700, 500],
        [850, 1300, 650, 450],
    ])
    fares = np.array([30, 25, 35, 40])
    return ride_table, fares


def test_get_monthly_ride_totals() -> bool:
    print("---------------------------------")
    ride_table, _ = get_sample_transit()
    actual = get_monthly_ride_totals(ride_table)
    expected = np.array([3000, 3200, 3250])

    print("輸入：3 個月、4 條路線的搭乘人次")
    print(f"預期每月搭乘人次總和：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_route_ride_totals() -> bool:
    print("---------------------------------")
    ride_table, _ = get_sample_transit()
    actual = get_route_ride_totals(ride_table)
    expected = np.array([2550, 3600, 1950, 1350])

    print("輸入：3 個月、4 條路線的搭乘人次")
    print(f"預期各路線搭乘人次總和：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_fare_amounts() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_fare_amounts(ride_table, fares)
    expected = np.array([
        [24000, 30000, 21000, 16000],
        [27000, 27500, 24500, 20000],
        [25500, 32500, 22750, 18000],
    ])

    print("輸入：搭乘人次與路線票價")
    print(f"預期票價收入：\n{expected}")
    print(f"實際：\n{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_monthly_fare_totals() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_monthly_fare_totals(ride_table, fares)
    expected = np.array([91000, 99000, 98750])

    print("輸入：搭乘人次與路線票價")
    print(f"預期每月票價收入總和：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_route_fare_totals() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_route_fare_totals(ride_table, fares)
    expected = np.array([76500, 90000, 68250, 54000])

    print("輸入：搭乘人次與路線票價")
    print(f"預期各路線票價收入總和：{expected}")
    print(f"實際：{actual}")

    if isinstance(actual, np.ndarray) and actual.tolist() == expected.tolist():
        print("通過")
        return True

    print("失敗")
    return False


def test_get_total_fare_amount() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_total_fare_amount(ride_table, fares)
    expected = 288750

    print("輸入：搭乘人次與路線票價")
    print(f"預期全部票價收入總和：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_best_route_index() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_best_route_index(ride_table, fares)
    expected = 1

    print("輸入：搭乘人次與路線票價")
    print(f"預期票價收入最高的路線索引：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_best_route_name() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    route_names = ["板南線", "淡水信義線", "松山新店線", "中和新蘆線"]
    actual = get_best_route_name(route_names, ride_table, fares)
    expected = "淡水信義線"

    print("輸入：路線名稱、搭乘人次與路線票價")
    print(f"預期票價收入最高的路線：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_transit_report() -> bool:
    print("---------------------------------")
    ride_table, fares = get_sample_transit()
    actual = get_transit_report(ride_table, fares)

    expected_monthly_ride_totals = [3000, 3200, 3250]
    expected_route_fare_totals = [76500, 90000, 68250, 54000]
    expected_total_amount = 288750

    print("輸入：搭乘人次與路線票價")
    print("預期報表包含 monthly_ride_totals、route_fare_totals、total_amount")
    print(f"實際：{actual}")

    monthly_is_correct = (
        actual.get("monthly_ride_totals").tolist()
        == expected_monthly_ride_totals
    )
    route_is_correct = (
        actual.get("route_fare_totals").tolist()
        == expected_route_fare_totals
    )

    if (
        monthly_is_correct
        and route_is_correct
        and actual.get("total_amount") == expected_total_amount
    ):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_get_monthly_ride_totals),
        run_test(test_get_route_ride_totals),
        run_test(test_get_fare_amounts),
        run_test(test_get_monthly_fare_totals),
        run_test(test_get_route_fare_totals),
        run_test(test_get_total_fare_amount),
        run_test(test_get_best_route_index),
        run_test(test_get_best_route_name),
        run_test(test_get_transit_report),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
