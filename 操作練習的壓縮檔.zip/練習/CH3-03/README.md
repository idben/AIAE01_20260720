# CH3-03 NumPy 捷運搭乘練習

這個練習會讓你用 NumPy 處理各月、各捷運路線的搭乘人次與票價收入。

這是本章的挑戰練習。你會把搭乘人次、路線票價、`axis` 加總、最大值位置與 dict 報表組合在一起。

你主要修改：

```text
main_numpy_transit.py
```

測試檔：

```text
test_numpy_transit.py
```

完成後，在這個資料夾中執行：

```bash
python test_numpy_transit.py
```

## 資料說明

測試檔會使用 3 個月、4 條路線的搭乘人次：

```python
ride_table = np.array([
    [800, 1200, 600, 400],
    [900, 1100, 700, 500],
    [850, 1300, 650, 450],
])

fares = np.array([30, 25, 35, 40])
```

你可以這樣理解：

- 每一列代表一個月。
- 每一欄代表一條捷運路線。
- `fares` 代表每條路線的票價。

## 練習目標

請完成下列函式：

- `get_monthly_ride_totals(ride_table)`：回傳每個月的搭乘人次總和。
- `get_route_ride_totals(ride_table)`：回傳每條路線的搭乘人次總和。
- `get_fare_amounts(ride_table, fares)`：回傳每個月、每條路線的票價收入。
- `get_monthly_fare_totals(ride_table, fares)`：回傳每個月的票價收入總和。
- `get_route_fare_totals(ride_table, fares)`：回傳每條路線的票價收入總和。
- `get_total_fare_amount(ride_table, fares)`：回傳全部票價收入總和。
- `get_best_route_index(ride_table, fares)`：回傳票價收入最高的路線索引。
- `get_best_route_name(route_names, ride_table, fares)`：回傳票價收入最高的路線名稱。
- `get_transit_report(ride_table, fares)`：回傳一個整理後的搭乘報表 dict。

## 難度定位

挑戰：需要把前面函式的思路組合起來，先算票價收入，再做加總、找最大值位置，最後整理成報表。

## 提示

每月搭乘人次總和：

```python
ride_table.sum(axis=1)
```

各路線搭乘人次總和：

```python
ride_table.sum(axis=0)
```

每個月、每條路線的票價收入：

```python
ride_table * fares
```

票價收入最高路線的位置：

```python
route_fare_totals.argmax()
```

回傳報表 dict：

```python
{
    "monthly_ride_totals": ...,
    "route_fare_totals": ...,
    "total_amount": ...,
}
```
