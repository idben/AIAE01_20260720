import numpy as np


def get_monthly_ride_totals(ride_table):
    # ride_table 每列代表一個月，每欄代表一條捷運路線
    # 請回傳每個月的搭乘人次總和
    raise NotImplementedError("請完成 get_monthly_ride_totals")


def get_route_ride_totals(ride_table):
    # 請回傳每條路線的搭乘人次總和
    raise NotImplementedError("請完成 get_route_ride_totals")


def get_fare_amounts(ride_table, fares):
    # ride_table 是搭乘人次，fares 是每條路線的票價
    # 請回傳每個月、每條路線的票價收入
    raise NotImplementedError("請完成 get_fare_amounts")


def get_monthly_fare_totals(ride_table, fares):
    # 請回傳每個月的票價收入總和
    raise NotImplementedError("請完成 get_monthly_fare_totals")


def get_route_fare_totals(ride_table, fares):
    # 請回傳每條路線的票價收入總和
    raise NotImplementedError("請完成 get_route_fare_totals")


def get_total_fare_amount(ride_table, fares):
    # 請回傳全部路線、全部月份的票價收入總和
    raise NotImplementedError("請完成 get_total_fare_amount")


def get_best_route_index(ride_table, fares):
    # 挑戰：請先計算每條路線的票價收入總和
    # 再回傳票價收入最高的路線索引
    raise NotImplementedError("請完成 get_best_route_index")


def get_best_route_name(route_names, ride_table, fares):
    # 挑戰：請回傳票價收入最高的路線名稱
    raise NotImplementedError("請完成 get_best_route_name")


def get_transit_report(ride_table, fares):
    # 挑戰：請回傳一個 dict，整理三種分析結果
    # {
    #     "monthly_ride_totals": 每月搭乘人次總和,
    #     "route_fare_totals": 各路線票價收入總和,
    #     "total_amount": 全部票價收入總和,
    # }
    raise NotImplementedError("請完成 get_transit_report")
