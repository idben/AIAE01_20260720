from pathlib import Path

import pandas as pd

from main_employee_filter import (
    get_active_employees,
    get_employees_by_dept,
    get_senior_active_employees,
    get_top_active_employees,
    load_employees_csv,
    sort_by_performance_desc,
)


DATA_PATH = Path(__file__).parent / "data" / "employees.csv"


def get_employee_df():
    return pd.DataFrame({
        "姓名": ["怡君", "志明", "美玲", "建宏", "淑芬", "俊傑", "雅婷"],
        "年資": [1, 2, 1, 3, 2, 3, 1],
        "部門": ["業務部", "研發部", "研發部", "行銷部", "研發部", "業務部", "行銷部"],
        "績效": [82, 91, 76, 88, 95, 84, 79],
        "是否在職": [True, True, False, True, False, True, True],
    })


def test_load_employees_csv() -> bool:
    print("---------------------------------")
    actual = load_employees_csv(DATA_PATH)
    expected = get_employee_df()

    print("預期讀取 CSV 後的資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_active_employees() -> bool:
    print("---------------------------------")
    actual = get_active_employees(get_employee_df())
    expected_names = ["怡君", "志明", "建宏", "俊傑", "雅婷"]
    actual_names = actual["姓名"].tolist()

    print(f"預期在職員工：{expected_names}")
    print(f"實際：{actual_names}")

    if isinstance(actual, pd.DataFrame) and actual_names == expected_names:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_employees_by_dept() -> bool:
    print("---------------------------------")
    actual = get_employees_by_dept(get_employee_df(), "研發部")
    expected_names = ["志明", "美玲", "淑芬"]
    actual_names = actual["姓名"].tolist()

    print("輸入部門：研發部")
    print(f"預期員工：{expected_names}")
    print(f"實際：{actual_names}")

    if isinstance(actual, pd.DataFrame) and actual_names == expected_names:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_senior_active_employees() -> bool:
    print("---------------------------------")
    actual = get_senior_active_employees(get_employee_df())
    expected_names = ["志明", "建宏", "俊傑"]
    actual_names = actual["姓名"].tolist()

    print("預期年資大於等於 2 且在職員工：")
    print(expected_names)
    print(f"實際：{actual_names}")

    if isinstance(actual, pd.DataFrame) and actual_names == expected_names:
        print("通過")
        return True

    print("失敗")
    return False


def test_sort_by_performance_desc() -> bool:
    print("---------------------------------")
    actual = sort_by_performance_desc(get_employee_df())
    expected_names = ["淑芬", "志明", "建宏", "俊傑", "怡君", "雅婷", "美玲"]
    actual_names = actual["姓名"].tolist()

    print("預期依績效由高到低：")
    print(expected_names)
    print(f"實際：{actual_names}")

    if isinstance(actual, pd.DataFrame) and actual_names == expected_names:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_top_active_employees() -> bool:
    print("---------------------------------")
    actual = get_top_active_employees(get_employee_df(), 3)
    expected_names = ["志明", "建宏", "俊傑"]
    actual_names = actual["姓名"].tolist()

    print("預期在職且績效前三名：")
    print(expected_names)
    print(f"實際：{actual_names}")

    if isinstance(actual, pd.DataFrame) and actual_names == expected_names:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_employees_csv),
        run_test(test_get_active_employees),
        run_test(test_get_employees_by_dept),
        run_test(test_get_senior_active_employees),
        run_test(test_sort_by_performance_desc),
        run_test(test_get_top_active_employees),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
