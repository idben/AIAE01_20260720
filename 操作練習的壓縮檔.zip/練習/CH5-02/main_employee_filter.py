import pandas as pd


def load_employees_csv(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV 檔案，並回傳 DataFrame
    raise NotImplementedError("請完成 load_employees_csv")


def get_active_employees(emp_df):
    # 基礎：請回傳是否在職為 True 的員工資料
    raise NotImplementedError("請完成 get_active_employees")


def get_employees_by_dept(emp_df, dept_name):
    # 基礎：請回傳指定部門的員工資料
    raise NotImplementedError("請完成 get_employees_by_dept")


def get_senior_active_employees(emp_df):
    # 應用：請回傳年資大於等於 2 且在職的員工資料
    raise NotImplementedError("請完成 get_senior_active_employees")


def sort_by_performance_desc(emp_df):
    # 應用：請依照績效從高到低排序
    raise NotImplementedError("請完成 sort_by_performance_desc")


def get_top_active_employees(emp_df, count):
    # 挑戰：請先篩選在職，再依照績效從高到低排序，最後回傳前 count 筆
    raise NotImplementedError("請完成 get_top_active_employees")
