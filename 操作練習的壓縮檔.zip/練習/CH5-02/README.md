# CH5-02 Pandas 篩選、排序與多條件查詢練習

這是第 5 章的第二個練習。你會處理一份員工名單資料，練習單一條件篩選、多條件查詢，以及依照指定欄位排序。

你主要修改：

```text
main_employee_filter.py
```

測試檔：

```text
test_employee_filter.py
```

資料檔：

```text
data/employees.csv
```

完成後，在這個資料夾中執行：

```bash
python test_employee_filter.py
```

## 難度定位

應用：這一題開始組合多個條件。你需要分清楚單一條件、同時符合兩個條件，以及排序後的資料順序。

## 練習目標

請完成下列函式：

- `load_employees_csv(csv_path)`：讀取 CSV，回傳 DataFrame。
- `get_active_employees(emp_df)`：回傳在職員工資料。
- `get_employees_by_dept(emp_df, dept_name)`：回傳指定部門的員工資料。
- `get_senior_active_employees(emp_df)`：回傳年資大於等於 2 且在職的員工資料。
- `sort_by_performance_desc(emp_df)`：依照 `績效` 從高到低排序。
- `get_top_active_employees(emp_df, count)`：先篩選在職，再依照 `績效` 從高到低排序，最後回傳前 `count` 筆。

## 資料欄位

`data/employees.csv` 有下列欄位：

- `姓名`
- `年資`
- `部門`
- `績效`
- `是否在職`

## 提示

讀取 CSV：

```python
pd.read_csv(csv_path)
```

單一條件篩選：

```python
emp_df[emp_df["是否在職"] == True]
```

多條件篩選可以先拆成變數：

```python
is_senior = emp_df["年資"] >= 2
is_active = emp_df["是否在職"] == True
result_df = emp_df[is_senior & is_active]
```

排序：

```python
emp_df.sort_values("績效", ascending=False)
```

## 常見錯誤

使用 `&` 或 `|` 時，每個條件都要完整寫出來。不要把 Python 的 `and`、`or` 直接用在 Pandas Series 條件上。

如果看到 `FileNotFoundError`，請確認你是在 `CH5-02` 資料夾中執行測試檔，或確認 `data/employees.csv` 是否存在。
