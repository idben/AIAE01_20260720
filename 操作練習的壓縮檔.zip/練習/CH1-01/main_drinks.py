def get_total_amount(orders):
    # 請回傳所有訂單的金額總和
    raise NotImplementedError("請完成 get_total_amount")


def get_average_amount(orders):
    # 請回傳平均每筆訂單金額
    raise NotImplementedError("請完成 get_average_amount")


def get_high_amount_items(orders, amount_limit):
    # 請回傳金額大於等於 amount_limit 的品項名稱 list
    raise NotImplementedError("請完成 get_high_amount_items")
