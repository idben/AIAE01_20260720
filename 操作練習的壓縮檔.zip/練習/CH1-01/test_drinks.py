from main_drinks import (
    get_average_amount,
    get_high_amount_items,
    get_total_amount,
)


def build_orders():
    return [
        {"品項": "紅茶", "金額": 30},
        {"品項": "奶茶", "金額": 45},
        {"品項": "綠茶", "金額": 35},
        {"品項": "珍珠奶茶", "金額": 60},
        {"品項": "紅茶", "金額": 30},
    ]


def test_get_total_amount():
    print("---------------------------------")
    orders = build_orders()
    expected = 200

    try:
        actual = get_total_amount(orders)
    except NotImplementedError as error:
        print("測試：計算總銷售金額")
        print(error)
        print("失敗")
        return False

    print("測試：計算總銷售金額")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_average_amount():
    print("---------------------------------")
    orders = build_orders()
    expected = 40

    try:
        actual = get_average_amount(orders)
    except NotImplementedError as error:
        print("測試：計算平均每筆訂單金額")
        print(error)
        print("失敗")
        return False

    print("測試：計算平均每筆訂單金額")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_get_high_amount_items():
    print("---------------------------------")
    orders = build_orders()
    expected = ["奶茶", "珍珠奶茶"]

    try:
        actual = get_high_amount_items(orders, 45)
    except NotImplementedError as error:
        print("測試：找出金額大於等於 45 的品項")
        print(error)
        print("失敗")
        return False

    print("測試：找出金額大於等於 45 的品項")
    print(f"預期：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def main():
    results = [
        test_get_total_amount(),
        test_get_average_amount(),
        test_get_high_amount_items(),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
