# CH1-01

這個練習會讓你用已經學過的 list、dict、for 迴圈與函式，完成一個很小的資料分析流程。

這一題不需要使用 NumPy、Pandas 或 Matplotlib，也不需要讀取檔案。重點是先練習「用資料回答問題」。

難度：基礎。這一題的資料是乾淨的，重點是練習加總、平均與條件篩選。

## 練習目標

你要完成 `main_drinks.py` 裡的三個函式：

1. `get_total_amount(orders)`：回傳總銷售金額。
2. `get_average_amount(orders)`：回傳平均每筆訂單金額。
3. `get_high_amount_items(orders, amount_limit)`：回傳金額大於等於指定金額的品項名稱。

## 資料長什麼樣子

測試檔會使用下面這份飲料店訂單資料：

```python
orders = [
    {"品項": "紅茶", "金額": 30},
    {"品項": "奶茶", "金額": 45},
    {"品項": "綠茶", "金額": 35},
    {"品項": "珍珠奶茶", "金額": 60},
    {"品項": "紅茶", "金額": 30},
]
```

每一筆訂單是一個 dict，裡面有兩個欄位：

- `品項`：飲料名稱。
- `金額`：這筆訂單的金額。

## 操作步驟

1. 用 VSCode 開啟本練習資料夾。
2. 打開 `main_drinks.py`。
3. 找到 `raise NotImplementedError(...)` 的位置。
4. 用你自己的程式碼完成函式。
5. 在終端機執行測試檔。

```bash
python test_drinks.py
```

如果你的電腦目前只能使用 `python3`，可以改成：

```bash
python3 test_drinks.py
```

## 預期結果

全部完成後，測試檔會顯示三題都通過：

```text
============= 全部通過 ==============
3 通過，0 失敗
```

## 常見提醒

- 你只需要修改 `main_drinks.py`。
- 不需要修改 `test_drinks.py`。
- 如果看到 `NotImplementedError`，代表函式還沒有完成。
- 如果測試失敗，先看「預期」和「實際」的差異，再回去調整函式。
