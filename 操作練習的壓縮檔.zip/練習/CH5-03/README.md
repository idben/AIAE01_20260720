# CH5-03 Pandas 缺失值與重複資料整理練習

這是第 5 章的第三個練習。你會處理一份比較接近真實狀況的二手拍賣資料：有缺失值，也有重複拍賣。這題會把本章的資料整理觀念串在一起。

你主要修改：

```text
main_deal_cleaning.py
```

測試檔：

```text
test_deal_cleaning.py
```

資料檔：

```text
data/deals.csv
```

完成後，在這個資料夾中執行：

```bash
python test_deal_cleaning.py
```

## 難度定位

挑戰：需要你組合 `isna()`、`dropna()`、`fillna()`、`drop_duplicates()`、新增欄位和排序。每一步都不難，但順序要想清楚。

## 練習目標

請完成下列函式：

- `load_deals_csv(csv_path)`：讀取 CSV，回傳 DataFrame。
- `count_missing_values(deals_df)`：回傳每一欄缺失值數量的 dict。
- `drop_missing_product_rows(deals_df)`：刪除 `商品` 缺失的列。
- `fill_missing_quantity(deals_df)`：把 `數量` 缺失值補成 1。
- `remove_duplicate_deals(deals_df)`：依照 `拍賣編號` 移除重複拍賣，保留第一筆。
- `clean_deal_records(deals_df)`：整合清理流程，最後新增 `成交額` 並依 `成交額` 從高到低排序。

## 清理流程

`clean_deal_records()` 請依照下列順序處理：

1. 刪除 `商品` 缺失的列。
2. 將 `數量` 缺失值補成 1。
3. 依照 `拍賣編號` 移除重複拍賣，保留第一筆。
4. 新增 `成交額` 欄位，內容為 `數量 * 單價`。
5. 依照 `成交額` 從高到低排序。

## 提示

讀取 CSV：

```python
pd.read_csv(csv_path)
```

CSV 中的空格讀進來會變成 `NaN`，可以直接用本章的缺失值方法處理。

檢查缺失值數量：

```python
deals_df.isna().sum().to_dict()
```

刪除指定欄位缺失的列：

```python
deals_df.dropna(subset=["商品"])
```

依照某欄移除重複資料：

```python
deals_df.drop_duplicates(subset=["拍賣編號"])
```

## 常見錯誤

這題的測試會檢查原本傳入的 DataFrame 是否被改到。每個函式中建議先用 `copy()` 產生一份新資料，再對新資料做整理。

如果看到 `FileNotFoundError`，請確認你是在 `CH5-03` 資料夾中執行測試檔，或確認 `data/deals.csv` 是否存在。
