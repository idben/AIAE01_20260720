import pandas as pd


def load_deals_csv(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV 檔案，並回傳 DataFrame
    raise NotImplementedError("請完成 load_deals_csv")


def count_missing_values(deals_df):
    # 基礎：請回傳每一欄缺失值數量的 dict
    raise NotImplementedError("請完成 count_missing_values")


def drop_missing_product_rows(deals_df):
    # 基礎：請刪除商品欄位缺失的列
    # 不要改到傳入的 deals_df
    raise NotImplementedError("請完成 drop_missing_product_rows")


def fill_missing_quantity(deals_df):
    # 應用：請將數量欄位的缺失值補成 1
    # 不要改到傳入的 deals_df
    raise NotImplementedError("請完成 fill_missing_quantity")


def remove_duplicate_deals(deals_df):
    # 應用：請依照拍賣編號移除重複拍賣，保留第一筆
    raise NotImplementedError("請完成 remove_duplicate_deals")


def clean_deal_records(deals_df):
    # 挑戰：請依照 README 的清理流程，回傳整理後的 DataFrame
    # 最後的 DataFrame 需含成交額欄位（數量 * 單價），並依成交額由高到低排序
    # 不要改到傳入的 deals_df
    raise NotImplementedError("請完成 clean_deal_records")
