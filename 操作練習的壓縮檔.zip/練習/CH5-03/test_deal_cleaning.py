from pathlib import Path

import pandas as pd

from main_deal_cleaning import (
    clean_deal_records,
    count_missing_values,
    drop_missing_product_rows,
    fill_missing_quantity,
    load_deals_csv,
    remove_duplicate_deals,
)


DATA_PATH = Path(__file__).parent / "data" / "deals.csv"


def get_dirty_deals_df():
    return pd.DataFrame({
        "拍賣編號": [301, 302, 302, 303, 304, 305, 306],
        "商品": ["模型", "公仔", "公仔", None, "海報", "模型", "徽章"],
        "數量": [2, 5, 5, 1, None, 3, 4],
        "單價": [45, 10, 10, 30, 25, 45, 20],
    })


def test_load_deals_csv() -> bool:
    print("---------------------------------")
    actual = load_deals_csv(DATA_PATH)
    expected = get_dirty_deals_df()

    print("預期讀取 CSV 後的資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def get_expected_clean_df():
    return pd.DataFrame({
        "拍賣編號": [305, 301, 306, 302, 304],
        "商品": ["模型", "模型", "徽章", "公仔", "海報"],
        "數量": [3.0, 2.0, 4.0, 5.0, 1.0],
        "單價": [45, 45, 20, 10, 25],
        "成交額": [135.0, 90.0, 80.0, 50.0, 25.0],
    }, index=[5, 0, 6, 1, 4])


def test_count_missing_values() -> bool:
    print("---------------------------------")
    actual = count_missing_values(get_dirty_deals_df())
    expected = {
        "拍賣編號": 0,
        "商品": 1,
        "數量": 1,
        "單價": 0,
    }

    print("預期缺失值數量：")
    print(expected)
    print("實際：")
    print(actual)

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_drop_missing_product_rows() -> bool:
    print("---------------------------------")
    original_df = get_dirty_deals_df()
    actual = drop_missing_product_rows(original_df)
    actual_deal_ids = actual["拍賣編號"].tolist()
    expected_deal_ids = [301, 302, 302, 304, 305, 306]

    print(f"預期保留拍賣編號：{expected_deal_ids}")
    print(f"實際：{actual_deal_ids}")

    original_was_not_changed = original_df["商品"].isna().sum() == 1

    if (
        isinstance(actual, pd.DataFrame)
        and actual_deal_ids == expected_deal_ids
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_fill_missing_quantity() -> bool:
    print("---------------------------------")
    original_df = get_dirty_deals_df()
    actual = fill_missing_quantity(original_df)
    expected_quantities = [2.0, 5.0, 5.0, 1.0, 1.0, 3.0, 4.0]
    actual_quantities = actual["數量"].tolist()

    print(f"預期數量：{expected_quantities}")
    print(f"實際：{actual_quantities}")

    original_was_not_changed = original_df["數量"].isna().sum() == 1

    if actual_quantities == expected_quantities and original_was_not_changed:
        print("通過")
        return True

    print("失敗")
    return False


def test_remove_duplicate_deals() -> bool:
    print("---------------------------------")
    actual = remove_duplicate_deals(get_dirty_deals_df())
    actual_deal_ids = actual["拍賣編號"].tolist()
    expected_deal_ids = [301, 302, 303, 304, 305, 306]

    print(f"預期保留拍賣編號：{expected_deal_ids}")
    print(f"實際：{actual_deal_ids}")

    if isinstance(actual, pd.DataFrame) and actual_deal_ids == expected_deal_ids:
        print("通過")
        return True

    print("失敗")
    return False


def test_clean_deal_records() -> bool:
    print("---------------------------------")
    original_df = get_dirty_deals_df()
    actual = clean_deal_records(original_df)
    expected = get_expected_clean_df()

    print("預期清理後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "成交額" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_deals_csv),
        run_test(test_count_missing_values),
        run_test(test_drop_missing_product_rows),
        run_test(test_fill_missing_quantity),
        run_test(test_remove_duplicate_deals),
        run_test(test_clean_deal_records),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
