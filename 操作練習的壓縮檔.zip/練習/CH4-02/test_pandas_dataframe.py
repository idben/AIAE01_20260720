import pandas as pd

from main_pandas_dataframe import (
    add_average_column,
    add_total_column,
    create_rainfall_dataframe,
    get_january_rainfall,
    get_month_columns,
    get_cities_with_average,
)


def get_expected_rainfall_df():
    return pd.DataFrame({
        "城市": ["台北", "高雄", "台中", "花蓮"],
        "一月": [120, 60, 90, 200],
        "二月": [80, 40, 70, 150],
        "三月": [100, 50, 110, 130],
    })


def test_create_rainfall_dataframe() -> bool:
    print("---------------------------------")
    actual = create_rainfall_dataframe()
    expected = get_expected_rainfall_df()

    print("預期降雨量表：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_january_rainfall() -> bool:
    print("---------------------------------")
    actual = get_january_rainfall(get_expected_rainfall_df())
    expected = pd.Series([120, 60, 90, 200], name="一月")

    print("預期一月降雨量：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.Series) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_month_columns() -> bool:
    print("---------------------------------")
    actual = get_month_columns(get_expected_rainfall_df())
    expected = get_expected_rainfall_df()[["一月", "二月", "三月"]]

    print("預期三個月降雨欄：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_total_column() -> bool:
    print("---------------------------------")
    original_df = get_expected_rainfall_df()
    actual = add_total_column(original_df)
    expected = get_expected_rainfall_df()
    expected["總降雨"] = [300, 150, 270, 480]

    print("預期新增總降雨欄：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "總降雨" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_average_column() -> bool:
    print("---------------------------------")
    original_df = get_expected_rainfall_df()
    actual = add_average_column(original_df)
    expected = get_expected_rainfall_df()
    expected["平均"] = [100.0, 50.0, 90.0, 160.0]

    print("預期新增平均欄：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "平均" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_cities_with_average() -> bool:
    print("---------------------------------")
    original_df = get_expected_rainfall_df()
    actual = get_cities_with_average(original_df)
    expected = get_expected_rainfall_df()
    expected["總降雨"] = [300, 150, 270, 480]
    expected["平均"] = [100.0, 50.0, 90.0, 160.0]

    print("預期同時新增總降雨與平均：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = (
        "總降雨" not in original_df.columns
        and "平均" not in original_df.columns
    )

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_create_rainfall_dataframe),
        run_test(test_get_january_rainfall),
        run_test(test_get_month_columns),
        run_test(test_add_total_column),
        run_test(test_add_average_column),
        run_test(test_get_cities_with_average),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
