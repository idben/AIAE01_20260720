# CH4-02 Pandas DataFrame 欄位練習

這是第 4 章的第二個練習。你會處理一張各城市三個月降雨量表，練習建立 `DataFrame`、選取單欄與多欄，並新增 `總降雨` 和 `平均` 欄位。

你主要修改：

```text
main_pandas_dataframe.py
```

測試檔：

```text
test_pandas_dataframe.py
```

完成後，在這個資料夾中執行：

```bash
python test_pandas_dataframe.py
```

## 難度定位

中階：從一欄資料進入表格資料，需要分清楚 `Series` 和 `DataFrame` 的回傳差異。

## 練習目標

請完成下列函式：

- `create_rainfall_dataframe()`：建立指定格式的降雨量 DataFrame。
- `get_january_rainfall(rainfall_df)`：回傳 `一月` 單欄 Series。
- `get_month_columns(rainfall_df)`：回傳 `一月`、`二月`、`三月` 三欄 DataFrame。
- `add_total_column(rainfall_df)`：回傳新增 `總降雨` 欄位後的 DataFrame。
- `add_average_column(rainfall_df)`：回傳新增 `平均` 欄位後的 DataFrame，平均四捨五入到小數第 1 位。
- `get_cities_with_average(rainfall_df)`：回傳同時包含 `總降雨` 和 `平均` 的 DataFrame。

## 指定資料

請建立下列表格（降雨量單位為 mm）：

| 城市 | 一月 | 二月 | 三月 |
| --- | ---: | ---: | ---: |
| 台北 | 120 | 80 | 100 |
| 高雄 | 60 | 40 | 50 |
| 台中 | 90 | 70 | 110 |
| 花蓮 | 200 | 150 | 130 |

## 提示

選取多欄：

```python
rainfall_df[["一月", "二月", "三月"]]
```

新增欄位：

```python
rainfall_df["總降雨"] = rainfall_df[["一月", "二月", "三月"]].sum(axis=1)
```

為了避免改到測試傳進來的原始資料，你可以先複製一份：

```python
result_df = rainfall_df.copy()
```
