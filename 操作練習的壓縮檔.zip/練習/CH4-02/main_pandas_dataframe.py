import pandas as pd


MONTH_COLUMNS = ["一月", "二月", "三月"]


def create_rainfall_dataframe():
    # 基礎：請依照 README 的指定資料建立 DataFrame
    raise NotImplementedError("請完成 create_rainfall_dataframe")


def get_january_rainfall(rainfall_df):
    # 基礎：請回傳一月單欄 Series
    raise NotImplementedError("請完成 get_january_rainfall")


def get_month_columns(rainfall_df):
    # 基礎：請回傳一月、二月、三月三欄 DataFrame
    raise NotImplementedError("請完成 get_month_columns")


def add_total_column(rainfall_df):
    # 應用：請回傳新增總降雨欄位後的 DataFrame
    # 不要改到傳入的 rainfall_df
    raise NotImplementedError("請完成 add_total_column")


def add_average_column(rainfall_df):
    # 應用：請回傳新增平均欄位後的 DataFrame
    # 平均請四捨五入到小數第 1 位
    # 不要改到傳入的 rainfall_df
    raise NotImplementedError("請完成 add_average_column")


def get_cities_with_average(rainfall_df):
    # 整合：請回傳同時包含總降雨與平均欄位的 DataFrame
    # 不要改到傳入的 rainfall_df
    raise NotImplementedError("請完成 get_cities_with_average")
