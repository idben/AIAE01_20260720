# CH5-01 Pandas CSV 讀取與欄位整理練習

這是第 5 章的第一個練習。你會讀取一份 CSV 演唱會購票資料，練習確認欄位名稱、重新命名欄位，並新增 `小計` 欄位。

你主要修改：

```text
main_csv_tickets.py
```

測試檔：

```text
test_csv_tickets.py
```

資料檔：

```text
data/tickets.csv
```

完成後，在這個資料夾中執行：

```bash
python test_csv_tickets.py
```

## 難度定位

基礎：先專心練習 `pd.read_csv()`、欄位名稱觀察、欄位重新命名與新增計算欄位。

## 練習目標

請完成下列函式：

- `load_tickets_csv(csv_path)`：讀取 CSV，回傳 DataFrame。
- `get_column_names(tickets_df)`：回傳欄位名稱 list。
- `rename_ticket_columns(tickets_df)`：將英文欄位改成中文欄位。
- `add_subtotal_column(tickets_df)`：新增 `小計` 欄位，內容為 `數量 * 單價`。
- `get_order_overview(tickets_df)`：回傳包含資料筆數、欄位名稱、總票款金額的 dict。

## CSV 欄位

原始 CSV 使用英文欄位：

| order_id | ticket_type | quantity | unit_price | paid |
| ---: | --- | ---: | ---: | --- |
| 201 | 搖滾區 | 2 | 3800 | yes |
| 202 | 看台區 | 1 | 2200 | yes |
| 203 | 搖滾區 | 3 | 3800 | no |

請在 `rename_ticket_columns()` 中改成：

```python
{
    "order_id": "訂單編號",
    "ticket_type": "票種",
    "quantity": "數量",
    "unit_price": "單價",
    "paid": "付款狀態",
}
```

## 提示

讀取 CSV：

```python
pd.read_csv(csv_path)
```

修改欄位名稱：

```python
tickets_df.rename(columns={...})
```

新增小計欄位前，建議先複製一份：

```python
result_df = tickets_df.copy()
```

## 常見錯誤

如果看到 `FileNotFoundError`，請確認你是在 `CH5-01` 資料夾中執行測試檔，或確認 `data/tickets.csv` 是否存在。
