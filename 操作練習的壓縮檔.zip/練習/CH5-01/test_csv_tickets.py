from pathlib import Path

import pandas as pd

from main_csv_tickets import (
    add_subtotal_column,
    get_column_names,
    get_order_overview,
    load_tickets_csv,
    rename_ticket_columns,
)


DATA_PATH = Path(__file__).parent / "data" / "tickets.csv"


def get_expected_raw_df():
    return pd.DataFrame({
        "order_id": [201, 202, 203, 204, 205, 206],
        "ticket_type": ["搖滾區", "看台區", "搖滾區", "特區", "看台區", "特區"],
        "quantity": [2, 1, 3, 2, 4, 2],
        "unit_price": [3800, 2200, 3800, 5600, 2200, 5600],
        "paid": ["yes", "yes", "no", "yes", "no", "yes"],
    })


def get_expected_renamed_df():
    return pd.DataFrame({
        "訂單編號": [201, 202, 203, 204, 205, 206],
        "票種": ["搖滾區", "看台區", "搖滾區", "特區", "看台區", "特區"],
        "數量": [2, 1, 3, 2, 4, 2],
        "單價": [3800, 2200, 3800, 5600, 2200, 5600],
        "付款狀態": ["yes", "yes", "no", "yes", "no", "yes"],
    })


def get_expected_with_subtotal_df():
    tickets_df = get_expected_renamed_df()
    tickets_df["小計"] = [7600, 2200, 11400, 11200, 8800, 11200]
    return tickets_df


def test_load_tickets_csv() -> bool:
    print("---------------------------------")
    actual = load_tickets_csv(DATA_PATH)
    expected = get_expected_raw_df()

    print("預期讀取 CSV 後的資料：")
    print(expected)
    print("實際：")
    print(actual)

    if isinstance(actual, pd.DataFrame) and actual.equals(expected):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_column_names() -> bool:
    print("---------------------------------")
    actual = get_column_names(get_expected_raw_df())
    expected = ["order_id", "ticket_type", "quantity", "unit_price", "paid"]

    print(f"預期欄位：{expected}")
    print(f"實際：{actual}")

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def test_rename_ticket_columns() -> bool:
    print("---------------------------------")
    original_df = get_expected_raw_df()
    actual = rename_ticket_columns(original_df)
    expected = get_expected_renamed_df()

    print("預期改名後資料：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "order_id" in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_add_subtotal_column() -> bool:
    print("---------------------------------")
    original_df = get_expected_renamed_df()
    actual = add_subtotal_column(original_df)
    expected = get_expected_with_subtotal_df()

    print("預期新增小計欄：")
    print(expected)
    print("實際：")
    print(actual)

    original_was_not_changed = "小計" not in original_df.columns

    if (
        isinstance(actual, pd.DataFrame)
        and actual.equals(expected)
        and original_was_not_changed
    ):
        print("通過")
        return True

    print("失敗")
    return False


def test_get_order_overview() -> bool:
    print("---------------------------------")
    actual = get_order_overview(get_expected_with_subtotal_df())
    expected = {
        "row_count": 6,
        "columns": ["訂單編號", "票種", "數量", "單價", "付款狀態", "小計"],
        "total_amount": 52400,
    }

    print("預期摘要：")
    print(expected)
    print("實際：")
    print(actual)

    if actual == expected:
        print("通過")
        return True

    print("失敗")
    return False


def run_test(test_function) -> bool:
    try:
        return test_function()
    except NotImplementedError as error:
        print(f"尚未完成：{error}")
        return False
    except Exception as error:
        print(f"執行時發生錯誤：{error}")
        return False


def main() -> None:
    results = [
        run_test(test_load_tickets_csv),
        run_test(test_get_column_names),
        run_test(test_rename_ticket_columns),
        run_test(test_add_subtotal_column),
        run_test(test_get_order_overview),
    ]

    passed = results.count(True)
    failed = results.count(False)

    if failed == 0:
        print("============= 全部通過 ==============")
    else:
        print("============= 測試失敗 ==============")

    print(f"{passed} 通過，{failed} 失敗")


main()
