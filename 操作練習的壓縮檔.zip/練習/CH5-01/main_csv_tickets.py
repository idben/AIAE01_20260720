import pandas as pd


def load_tickets_csv(csv_path):
    # 基礎：請讀取 csv_path 指定的 CSV 檔案，並回傳 DataFrame
    raise NotImplementedError("請完成 load_tickets_csv")


def get_column_names(tickets_df):
    # 基礎：請回傳欄位名稱 list
    raise NotImplementedError("請完成 get_column_names")


def rename_ticket_columns(tickets_df):
    # 基礎：請將英文欄位名稱改成 README 指定的中文欄位名稱
    # 不要改到傳入的 tickets_df
    raise NotImplementedError("請完成 rename_ticket_columns")


def add_subtotal_column(tickets_df):
    # 應用：請回傳新增小計欄位後的 DataFrame
    # 小計 = 數量 * 單價
    # 不要改到傳入的 tickets_df
    raise NotImplementedError("請完成 add_subtotal_column")


def get_order_overview(tickets_df):
    # 整合：請回傳一個 dict，key 為 row_count、columns、total_amount
    # row_count 是資料筆數，columns 是欄位名稱 list，total_amount 是小計加總
    raise NotImplementedError("請完成 get_order_overview")
